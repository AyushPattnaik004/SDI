from fastapi import APIRouter, Body
from fastapi.responses import PlainTextResponse

from utils.fb_utils import decrypt_request, encrypt_response
from core.keys import PHONE_NUMBER_PRIVATE_KEY
import json

reprint_appoinment_router = APIRouter()


@reprint_appoinment_router.post("/")
async def reprint_appoinment(body: dict = Body()):
    encrypted_flow_data_b64 = body["encrypted_flow_data"]
    encrypted_aes_key_b64 = body["encrypted_aes_key"]
    initial_vector_b64 = body["initial_vector"]

    decrypted_data, aes_key, iv = decrypt_request(
        encrypted_flow_data_b64,
        encrypted_aes_key_b64,
        initial_vector_b64,
        PHONE_NUMBER_PRIVATE_KEY,
    )

    print(decrypted_data)

    if decrypted_data["action"] == "ping":
        response = {"data": {"status": "active"}}
    elif decrypted_data["action"] == "INIT":
        response = {"screen": "REPRINT_APPOINTMENT_LETTER", "data": {"message": "success"}}
    elif decrypted_data["data"]["trigger"] == "reprint_selected":
        reference_number = decrypted_data["data"]["reference_number"]
        passport_number_or_email = decrypted_data["data"]["passport_number_or_email"]
        if reference_number == "":
            response = {
                "screen":"REPRINT_APPOINTMENT_LETTER",
                "data":{
                    "error_message":"please give the reference number",
                    "reprint_msg_visible":False
                }
            }
        elif passport_number_or_email == "":
            response = {
                "screen":"REPRINT_APPOINTMENT_LETTER",
                "data":{
                    "error_message":"please passport number or email.",
                    "reprint_msg_visible":False
                }
            }
        else:
            response = {
                "screen":"REPRINT_APPOINTMENT_LETTER",
                "data":{
                    "reprint_msg_visible":True,
                    "reprint_msg":f"✅ Appointment Found Successfully\n\n🆔 Appointment Reference Number: {reference_number}\n👤 Applicant Name: Ashutosh Ray\n📅 Appointment Date: 25 May 2026\n⏰ Time Slot: 10:00 AM\n📄 PDF Download Link:\nhttps://example.com/pdf/bls123.pdf"
                }
            }       



    encrypted_response = encrypt_response(response, aes_key, iv)
    return PlainTextResponse(content=encrypted_response, media_type="text/plain")
