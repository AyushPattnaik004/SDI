from fastapi import APIRouter, Body
from fastapi.responses import PlainTextResponse

from utils.fb_utils import decrypt_request, encrypt_response
from core.keys import PHONE_NUMBER_PRIVATE_KEY
import json

cancel_appoinment_router = APIRouter()


@cancel_appoinment_router.post("/")
async def cancel_appoinment(body: dict = Body()):
    encrypted_flow_data_b64 = body["encrypted_flow_data"]
    encrypted_aes_key_b64 = body["encrypted_aes_key"]
    initial_vector_b64 = body["initial_vector"]

    decrypted_data, aes_key, iv = decrypt_request(
        encrypted_flow_data_b64,
        encrypted_aes_key_b64,
        initial_vector_b64,
        PHONE_NUMBER_PRIVATE_KEY,
    )

    print(decrypted_data)

    if decrypted_data["action"] == "ping":
        response = {"data": {"status": "active"}}
    elif decrypted_data["action"] == "INIT":
        response = {
            "screen": "CANCEL_APPOINTMENT",
            "data": {
                "search_cancel_appointment_visible":True,
                "confirm_cancel_msg_visible":False,
                "cancel_appointment_visible":False,
                "cancelation_msg_visible":False,
                "cancelation_msg":"",
                "confirm_cancel_msg":""
            }
        }
    elif decrypted_data["data"]["trigger"] == "SEARCH_CANCEL_APPOINTMENT_SELECTED":
        reference_number = decrypted_data["data"]["reference_number"]
        passport_number_or_email = decrypted_data["data"]["passport_number_or_email"]
        if reference_number == "":
            response = {
                "screen":"CANCEL_APPOINTMENT",
                "data":{
                    "error_message":"please give the reference number",
                    "confirm_cancel_msg_visible":False,
                    "cancel_appointment_visible":False,
                    "cancelation_msg_visible":False,
                    "cancelation_msg":"",
                    "confirm_cancel_msg":""
                }
            }
        elif passport_number_or_email == "":
            response = {
                "screen":"CANCEL_APPOINTMENT",
                "data":{
                    "error_message":"please give passport number or email.",
                    "confirm_cancel_msg_visible":False,
                    "cancel_appointment_visible":False,
                    "cancelation_msg_visible":False,
                    "cancelation_msg":"",
                    "confirm_cancel_msg":""
                }
            }
        else:
            response = {
                "screen":"CANCEL_APPOINTMENT",
                "data":{
                    "confirm_cancel_msg_visible":True,
                    "confirm_cancel_msg":f"⚠️ Are you sure you want to cancel this appointment?\n\n🆔 Appointment Reference Number: {reference_number}\n👤 Applicant Name: Ashutosh Ray\n📅 Appointment Date: 25 May 2026\n⏰ Time Slot: 10:00 AM",
                    "cancel_appointment_visible":True
                }
            }    
    elif decrypted_data["data"]["trigger"] == "cancel_appointment_selected":
        reference_number = decrypted_data["data"]["reference_number"]
        response = {
            "screen":"CANCEL_APPOINTMENT",
            "data":{
                "cancelation_msg_visible":True,
                "cancelation_msg":f"❌ Appointment Cancelled Successfully\n\n🆔 Appointment Reference Number: {reference_number}",
                "search_cancel_appointment_visible":False,
                "confirm_cancel_msg_visible":False,
                "cancel_appointment_visible":False,
            }
        }

           



    encrypted_response = encrypt_response(response, aes_key, iv)
    return PlainTextResponse(content=encrypted_response, media_type="text/plain")
