from fastapi import APIRouter, Body
from fastapi.responses import PlainTextResponse

from utils.fb_utils import decrypt_request, encrypt_response
from core.keys import PHONE_NUMBER_PRIVATE_KEY
import json

schengen_travel_insurance_router = APIRouter()

def generate_insurance_message(departure_country,arrival_country,departure_date,return_date,travelers):

    message = f"🌍 {departure_country} ➝ {arrival_country}\n📅 {departure_date} - {return_date}\n👥 {travelers}\n\n🛡️ 5 Insurance Plans Available\n💰 Starting From $109.59"

    return message

def get_insurance_guarantee_message(insurance_type):

    insurance_type = insurance_type.lower()

    medical_expense = (
        "€30,000"
        if insurance_type == "basic"
        else "€200,000"
    )

    message = (
        f"📝 *Description*\n"
        f"✅ Medical Expenses abroad up to {medical_expense}\n"
        f"✅ Medical Repatriation\n"
        f"✅ 24/7 Travel Assistance\n"
        f"✅ Covid-19\n"
        f"❌ Luggage insurance\n"
        f"   📦 The insured is covered for loss of luggage by the carrier, theft, total/partial destruction, and delay.\n"
        f"❌ Personal Liability Abroad\n"
        f"✅ All Epidemics\n"
        f"✅ Epidemic Quarantine Costs\n"
        f"✅ Sports (search and rescue costs)\n"
        f"❌ Terrorism\n"
        f"✅ Legal Fees Abroad & Advance of Bail Abroad\n"
        f"✅ Legal Assistance\n"
        f"✅ Assistance for loss or theft abroad\n"
        f"✅ Psychological Assistance"
    )

    return message

def get_insurance_type_message(insurance_type):

    insurance_type = insurance_type.lower()

    if insurance_type == "basic":

        return "*Insurance Type*:- *BASIC*\n🛂 Schengen compliant\n🌍 Worldwide Coverage\n🚫 No deductible\n✈️ Single trip"

    elif insurance_type == "premier lite":

        return "*Insurance Type*:- PREMIER LITE\n🛂 Schengen compliant\n🌍 Worldwide Coverage\n💶 Deductible: €30\n✈️ Single trip"

    elif insurance_type == "premier":

        return "*Insurance Type*:- PREMIER\n🛂 Schengen compliant\n🌍 Worldwide Coverage\n🚫 No deductible\n✈️ Single trip"

    elif insurance_type == "annual lite":

        return "*Insurance Type*:- ANNUAL LITE\n📅 Annual\n♾️ Max days per trip: unlimited\n🛂 Schengen compliant\n🌍 Worldwide Coverage\n💶 Deductible: €30\n🔁 Multi-trip"

    elif insurance_type == "annual":

        return "*Insurance Type*:- ANNUAL\n📅 Annual\n♾️ Max days per trip: unlimited\n🛂 Schengen compliant\n🌍 Worldwide Coverage\n🚫 No deductible\n🔁 Multi-trip"

    else:

        return "❌ Invalid Insurance Type"

def build_insurance_card_message(data):
    insurance_details_message = data.get("insurance_details_message", "")
    insurance_type = data.get("insurance_type", "").replace("_", " ").upper()

    lines = insurance_details_message.split("\n")

    departure_line = lines[0].replace("🌍", "").strip() if len(lines) > 0 else ""
    date_line = lines[1].replace("📅", "").strip() if len(lines) > 1 else ""
    travelers_line = lines[2].replace("👥", "").strip() if len(lines) > 2 else ""
    price_line = lines[-1].replace("💰 Starting From", "").strip() if len(lines) > 0 else ""

    departure_country = ""
    arrival_country = ""
    if "➝" in departure_line:
        parts = departure_line.split("➝")
        departure_country = parts[0].strip()
        arrival_country = parts[1].strip()

    departure_date = ""
    arrival_date = ""
    if " - " in date_line:
        parts = date_line.split(" - ")
        departure_date = parts[0].strip()
        arrival_date = parts[1].strip()

    message = (
        f"🧾 *Plan* - {insurance_type}\n"
        f"🌍 *Departure Country* - {departure_country}\n"
        f"🎯 *Arrival Country* - {arrival_country}\n"
        f"📅 *Departure Date* - {departure_date}\n"
        f"📅 *Arrival Date* - {arrival_date}\n"
        f"👥 *Number of Travelers* - {travelers_line}\n"
        f"💰 *Price* - {price_line}"
    )

    return message

def get_price_details(person_count):

    base_price_per_person = 720

    base_price = base_price_per_person * int(person_count)

    gst_price = (base_price * 18) / 100

    total_price = base_price + gst_price

    return {
        "base": f"₹ {base_price}",
        "gst": f"₹ {gst_price}",
        "total": f"₹ {total_price}"
    }


def generate_travel_guidelines_message(start_date, end_date, travelers):

    traveler_count = int(str(travelers).split()[0])

    price_details = get_price_details(traveler_count)

    message = (
        f"📅 {start_date} to {end_date} | 👥 {travelers}\n\n"

        f"💳 *Payment Summary*\n"
        f"💰 Base Premium: {price_details['base']}\n"
        f"🧾 GST (18%): {price_details['gst']}\n"
        f"💵 Total Payable: {price_details['total']}\n\n"

        f"⚠️ *Important Guidelines*\n"
        f"🛂 Enter names exactly as they appear on passports\n"
        f"👶 Travellers must be between 6 months and 70 years old\n"
        f"📘 Valid passport required for all travellers\n"
        f"📧 Policy certificate will be emailed instantly after payment"
    )

    return message


insurance_list = [
    {
        "id": "basic",
        "title": "BASIC\n$109.59",
        "image": "iVBORw0KGgoAAAANSUhEUgAAAGwAAABnCAYAAADloacOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAvaSURBVHhe7Z19cBXHYcB/u3fv3r1PPX1LgGyMkYXMhy2DXTuAGTfBUNXUJLRATNrQNsauGex4nGLqBheSaUhIJ3amzaRxJ0nHaUIy6Uxn2jRtM9QenMR2neAE26pLEuzwZTsBJMST9L7udvvHexBJCGwQT2I9+9PsaPRu93bf/m73du9uT0JrrQEKJc2vT2lOZBUnhzTZvCZX1BQDTaiwXCaIlw+X9OHjit5BRVNaUp+U1MQFKV8Q8wSeK3Dk6GSWyUL8cH9Rt9U7tGasFRMQpaDcJVrMwDYrw7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDDGdQNzyl/cw6lSCUeA1mL0ZksFIaCkNa3RGAf++gujN18Q4xLW+PDdnCwWyiW66L28+xEChFJMjSV5bccXR2++IMbVJQoBovJT/sOGMUOlfsQl6ITGJcwy8VhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFVag8UH1eLofKmpAySCAixJiZico2Z/SGCUQAUThvGRzAm6gKOw9Vz98FpAqJFPK4Wp91FEe1JlLMI1WAO2rbuRBAoiJ59P4uFAG4WuMPnsQp5YmMjgBEgIgK8YdO4WpV/Uo7D1XN2wWUCpmXyrDiqmvIeB4acBGgNUkhSDgO3Ve2c2OmEa1CPICxVkBphUCD1mg0+VIRpRRaV15IfI40I9ZBDT9gtEJS/jsKfHzZKm6f3k4YlogLUU6nFQ6aSBgwv7aB+xcvY3o0hn86rxH7GyP/KlA1YRKocxwiJ46yddn72fXn2/h89+8jet+i0XFoclyG+o+zdckyvrV5O59cuRZ54igNjst0x2GKFDhoJOAJ6HBd6oSgTQqudlwWT72SmyI+s12XODDNcZgmJU6lEh3KaeqFRFTK0+FI2oWmQ2iucV1qhAQVEk0kWbVkKe+ZMQvyQySEJC0kHa7LLClpCvIsvaaTLWvWM7uunlQYEEHT4Tq0C02n1FzhuNWrzGFUNQ8BoEo01dXRmz3FrXO7mN3YSr5UwFEB7fE4d968mOP9J6lP16C0QqNpjfs0+3FiSuGhSSBoSyZodl3qpeB9HbP4+j0PsjjVyFWZFCnp0Oh7NPkxfB0SBWJCMC0Zpy4SIao1Cs3MTIoFrY3c0NrIlISPVIqYdBgczPKJb3yFJ/Y+i06kKaqAQliiIRals6GGtoSHDIsAhFqjBKRyQ7TEo8xvaWBuQw0ZV5IIg+pWaDWFqdO9hJDUp2vY+4v9DJYKbP29uxCD/ZSyx9m8Yh1DpSLf/79XSMTihBGfGtdlx5qP8NBt3TgDvcTDkHk1Gf7hz7ZwY0stt3fO4eEVd1GXSvPH6/+Ej//BR7g2neGR7tU8svz9qL63SKOZGU/wlY1/SXfnXErFHFdHY3z6j+5n69qNbF93P1/duJUNN99KJAyJR6M8vOpDzL/iKrQKSUmH7Uvv5GubtrJz/cd44qM7+MCSbgCkkPQVC2z93VV8ccNm7l3+QR5ZvZGvbniIRVPbqNVhVbvHqgkTQBGF8lMk4gl+8noPz7z0Y1Yuuo2rG6cwvXEaq5cs5d+ff4ZXjxwg4ccgGicCNGVqScfjSBXiaI0vIzTX1uNnprJzz3/xO1/+PAP5PPfu2MDCx7bz+ok3aK2tozaZRoTlNFEhaalvJO55NEiHUhAwf8uHuWH1HK6b08nTL/6I1TcupC4cQjouTZkMjbEEIjfA+zrnsXFpN4//yy5mbr2Pu594DFdWqmrwTTYvuJ5NK1az7bG/YfmaJdxyUxdhKeDB21fiKcUML1o1aVUT5gIFpRCJDMlYjNxQL7ue/R5hGLDy2nms7JxHrpDj757+Lnkt8KNRUn4CVACUl+IiJQyfDmgN8TQ3p2sRgJgymwX1LSAr40uhQQoQ5XTlKhMMhQFX1jfwjY2f5IdP/phnnn+BW6/rwnMjOI5b3q8QuEJA71Hu7JzHc6+8xNe+/2066ls5cKSHL31nF6AJ4k20z/otSkHAhnV/yO5//gHffWoP8ZhP3IuSpERUVK1aqydMApEwpDOVIRrxyIsk/33wlzz3yj5W/HY3y5cs45tPfY9D2T6KYYjnecxMpAiCgFBpEr7PYPYo2VNv4EmB0ppQ/aa70Vqjs4d5rZAj1FBSimQ0RrHvMP3ZY/iECDRKa7JonvzTB2ibOpVPfPlxHt2yhb/9n2fKBVVhuTvQuixYOhSDAC/iIXI53ijk6C8WiUf9cvwwQAXlhfif+foTbH98Gzv+aRsPfm4TD/3jpzkhYxws5Strmy89VRPmCHDDEjNrahEC8rkBpiRqWPvtJ7mqvolMxGP7f+xiRm0zhaEBHCFoS2XYPzTIy786yqLrF/DwHfdy38IV7Fx/H0orSmEIEY+fDfSTiMVYs+SD3NrYSigke4/8kq6Oa9m69mOsu34xj6/fBICQEkoBvf19zGho5q7lH6B73VrumN6OlLIy7BdE3EhZWN0V/P2LzzHv6na+tGkn721pY/PydXx01YcBgadK7H5+D66UfOqeh5jVtZCmpi5u6bqDTFM7g0IwVJ3eEADn0Ue3bRv94Tvls7v/jXwYjnk0OQKECmlL1zGloZF//ekL9OVz9B47QjoaZ3fPPp4/epioF0U6DnXpWvbs7+HQYJZDhw9Rm0yx6NrrmDplGrv3PsfhwQGe/cWrFHJ53uw7RgzBwjldzL1iOk/1/JSeg6+RiPosmTefjitn8ML+l/l57wleeP3nvHayly/86Ae0AA3NLdQ2txA4kp8cfJ3dB/aTRzCjtoH//FkPBwez9J46ya+P/YpFs69jWddNNDU2s+d/9/HWQJbvvPoqTx85yIs9LzG9uZX3zOnils651Dc2s+/oIQ72Hqc4qj4EINCkIx4PvPeOEdsulHG9p6Npy92cLBSHnS9+w+m5TxRICujTmgCBh8AJiigh0E6EIhqJxgNyunyZKh6GFFVIWyzGsTAkMnSKY34SKQQKQQyQQYn6qI8LHAwD4kpBGNASS5BVimCon2PRRPm8VO7zqMsPctKJUHTcMweZEOVWprU+8/qKGBAt5ol7Ps3RKG8WC+SKeYoRnyE0MQSxoISjSiRjKXwpeKtYIqcUBccZsy6EVkyLJTjwqUl8T8f50JWhfQg4wkFWsiqgUREP5UQoUD5vuEiS0sEVggAYcCSe51NU4AtJfyxNRrq4QqKBHKAj5S4srzUhggEpCTyfotZIIRjwU9RIh4iQhECIoN9PEvV86p0I9Y5LWjqVo1+QqcTVQB5N1vNR0qE/CEBIcl6MuJQ4CPLAKddlMJog1JpcqHEdh8Bxz5J1qalaCxtBZRR2fsrnkpEfqcooUTDmf8TSupxu+KiskkaUL2SNoNzOhjNGnsM5s//TrVSdfYyfvjRWaZ1jYUQLG8E5vshIzo5T7q7OIQsQQlTiDP9MjimLs2QxZp4jEJUpwpl4Y1SXkGemERPBxLSwtyEOVAbNlx19Y4q+MMxrYedBAiUEOXEZBsqT9vPdJ5toJrWFuZWwppDltvwJlJCIiy/OJUQgUATSY2eyhQNClq+Njo72DrmULWxShZ2+y/tI9g3WnehBSQ+hw9HRJgGB1CF5L8OHWm9gX2Wkea5z6dvxrhEmKy1seVBgQVhClWdCk87psWOI4kkvwaHKcP9iviPvJmFUvoyDwBFvP8qeMIaVo1i5IXqxrYtLLGzSBx0akGhcrXBR5d+THSrlcCpzrPHIutRMujCAIjCIuOzC0Dnmc5PJZSHM8s6xwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMMYl7PRThMKGtw2M47nG4YxLWE6p8nIbrRA2nDOgNShFeGZp0sUzrgdJ52x7gGw+jzNBS21MJtCaxliCvX/1udGbLohxCbNMPOPqEi0TjxVmGFaYYVhhhmGFGYYVZhj/DyzTUa235PK4AAAAAElFTkSuQmCC"
    },
    {
        "id": "premier_lite",
        "title": "PREMIER LITE\n$146.13",
        "image": "iVBORw0KGgoAAAANSUhEUgAAAGwAAABnCAYAAADloacOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAvaSURBVHhe7Z19cBXHYcB/u3fv3r1PPX1LgGyMkYXMhy2DXTuAGTfBUNXUJLRATNrQNsauGex4nGLqBheSaUhIJ3amzaRxJ0nHaUIy6Uxn2jRtM9QenMR2neAE26pLEuzwZTsBJMST9L7udvvHexBJCGwQT2I9+9PsaPRu93bf/m73du9uT0JrrQEKJc2vT2lOZBUnhzTZvCZX1BQDTaiwXCaIlw+X9OHjit5BRVNaUp+U1MQFKV8Q8wSeK3Dk6GSWyUL8cH9Rt9U7tGasFRMQpaDcJVrMwDYrw7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDDGdQNzyl/cw6lSCUeA1mL0ZksFIaCkNa3RGAf++gujN18Q4xLW+PDdnCwWyiW66L28+xEChFJMjSV5bccXR2++IMbVJQoBovJT/sOGMUOlfsQl6ITGJcwy8VhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFVag8UH1eLofKmpAySCAixJiZico2Z/SGCUQAUThvGRzAm6gKOw9Vz98FpAqJFPK4Wp91FEe1JlLMI1WAO2rbuRBAoiJ59P4uFAG4WuMPnsQp5YmMjgBEgIgK8YdO4WpV/Uo7D1XN2wWUCpmXyrDiqmvIeB4acBGgNUkhSDgO3Ve2c2OmEa1CPICxVkBphUCD1mg0+VIRpRRaV15IfI40I9ZBDT9gtEJS/jsKfHzZKm6f3k4YlogLUU6nFQ6aSBgwv7aB+xcvY3o0hn86rxH7GyP/KlA1YRKocxwiJ46yddn72fXn2/h89+8jet+i0XFoclyG+o+zdckyvrV5O59cuRZ54igNjst0x2GKFDhoJOAJ6HBd6oSgTQqudlwWT72SmyI+s12XODDNcZgmJU6lEh3KaeqFRFTK0+FI2oWmQ2iucV1qhAQVEk0kWbVkKe+ZMQvyQySEJC0kHa7LLClpCvIsvaaTLWvWM7uunlQYEEHT4Tq0C02n1FzhuNWrzGFUNQ8BoEo01dXRmz3FrXO7mN3YSr5UwFEB7fE4d968mOP9J6lP16C0QqNpjfs0+3FiSuGhSSBoSyZodl3qpeB9HbP4+j0PsjjVyFWZFCnp0Oh7NPkxfB0SBWJCMC0Zpy4SIao1Cs3MTIoFrY3c0NrIlISPVIqYdBgczPKJb3yFJ/Y+i06kKaqAQliiIRals6GGtoSHDIsAhFqjBKRyQ7TEo8xvaWBuQw0ZV5IIg+pWaDWFqdO9hJDUp2vY+4v9DJYKbP29uxCD/ZSyx9m8Yh1DpSLf/79XSMTihBGfGtdlx5qP8NBt3TgDvcTDkHk1Gf7hz7ZwY0stt3fO4eEVd1GXSvPH6/+Ej//BR7g2neGR7tU8svz9qL63SKOZGU/wlY1/SXfnXErFHFdHY3z6j+5n69qNbF93P1/duJUNN99KJAyJR6M8vOpDzL/iKrQKSUmH7Uvv5GubtrJz/cd44qM7+MCSbgCkkPQVC2z93VV8ccNm7l3+QR5ZvZGvbniIRVPbqNVhVbvHqgkTQBGF8lMk4gl+8noPz7z0Y1Yuuo2rG6cwvXEaq5cs5d+ff4ZXjxwg4ccgGicCNGVqScfjSBXiaI0vIzTX1uNnprJzz3/xO1/+PAP5PPfu2MDCx7bz+ok3aK2tozaZRoTlNFEhaalvJO55NEiHUhAwf8uHuWH1HK6b08nTL/6I1TcupC4cQjouTZkMjbEEIjfA+zrnsXFpN4//yy5mbr2Pu594DFdWqmrwTTYvuJ5NK1az7bG/YfmaJdxyUxdhKeDB21fiKcUML1o1aVUT5gIFpRCJDMlYjNxQL7ue/R5hGLDy2nms7JxHrpDj757+Lnkt8KNRUn4CVACUl+IiJQyfDmgN8TQ3p2sRgJgymwX1LSAr40uhQQoQ5XTlKhMMhQFX1jfwjY2f5IdP/phnnn+BW6/rwnMjOI5b3q8QuEJA71Hu7JzHc6+8xNe+/2066ls5cKSHL31nF6AJ4k20z/otSkHAhnV/yO5//gHffWoP8ZhP3IuSpERUVK1aqydMApEwpDOVIRrxyIsk/33wlzz3yj5W/HY3y5cs45tPfY9D2T6KYYjnecxMpAiCgFBpEr7PYPYo2VNv4EmB0ppQ/aa70Vqjs4d5rZAj1FBSimQ0RrHvMP3ZY/iECDRKa7JonvzTB2ibOpVPfPlxHt2yhb/9n2fKBVVhuTvQuixYOhSDAC/iIXI53ijk6C8WiUf9cvwwQAXlhfif+foTbH98Gzv+aRsPfm4TD/3jpzkhYxws5Strmy89VRPmCHDDEjNrahEC8rkBpiRqWPvtJ7mqvolMxGP7f+xiRm0zhaEBHCFoS2XYPzTIy786yqLrF/DwHfdy38IV7Fx/H0orSmEIEY+fDfSTiMVYs+SD3NrYSigke4/8kq6Oa9m69mOsu34xj6/fBICQEkoBvf19zGho5q7lH6B73VrumN6OlLIy7BdE3EhZWN0V/P2LzzHv6na+tGkn721pY/PydXx01YcBgadK7H5+D66UfOqeh5jVtZCmpi5u6bqDTFM7g0IwVJ3eEADn0Ue3bRv94Tvls7v/jXwYjnk0OQKECmlL1zGloZF//ekL9OVz9B47QjoaZ3fPPp4/epioF0U6DnXpWvbs7+HQYJZDhw9Rm0yx6NrrmDplGrv3PsfhwQGe/cWrFHJ53uw7RgzBwjldzL1iOk/1/JSeg6+RiPosmTefjitn8ML+l/l57wleeP3nvHayly/86Ae0AA3NLdQ2txA4kp8cfJ3dB/aTRzCjtoH//FkPBwez9J46ya+P/YpFs69jWddNNDU2s+d/9/HWQJbvvPoqTx85yIs9LzG9uZX3zOnils651Dc2s+/oIQ72Hqc4qj4EINCkIx4PvPeOEdsulHG9p6Npy92cLBSHnS9+w+m5TxRICujTmgCBh8AJiigh0E6EIhqJxgNyunyZKh6GFFVIWyzGsTAkMnSKY34SKQQKQQyQQYn6qI8LHAwD4kpBGNASS5BVimCon2PRRPm8VO7zqMsPctKJUHTcMweZEOVWprU+8/qKGBAt5ol7Ps3RKG8WC+SKeYoRnyE0MQSxoISjSiRjKXwpeKtYIqcUBccZsy6EVkyLJTjwqUl8T8f50JWhfQg4wkFWsiqgUREP5UQoUD5vuEiS0sEVggAYcCSe51NU4AtJfyxNRrq4QqKBHKAj5S4srzUhggEpCTyfotZIIRjwU9RIh4iQhECIoN9PEvV86p0I9Y5LWjqVo1+QqcTVQB5N1vNR0qE/CEBIcl6MuJQ4CPLAKddlMJog1JpcqHEdh8Bxz5J1qalaCxtBZRR2fsrnkpEfqcooUTDmf8TSupxu+KiskkaUL2SNoNzOhjNGnsM5s//TrVSdfYyfvjRWaZ1jYUQLG8E5vshIzo5T7q7OIQsQQlTiDP9MjimLs2QxZp4jEJUpwpl4Y1SXkGemERPBxLSwtyEOVAbNlx19Y4q+MMxrYedBAiUEOXEZBsqT9vPdJ5toJrWFuZWwppDltvwJlJCIiy/OJUQgUATSY2eyhQNClq+Njo72DrmULWxShZ2+y/tI9g3WnehBSQ+hw9HRJgGB1CF5L8OHWm9gX2Wkea5z6dvxrhEmKy1seVBgQVhClWdCk87psWOI4kkvwaHKcP9iviPvJmFUvoyDwBFvP8qeMIaVo1i5IXqxrYtLLGzSBx0akGhcrXBR5d+THSrlcCpzrPHIutRMujCAIjCIuOzC0Dnmc5PJZSHM8s6xwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMMYl7PRThMKGtw2M47nG4YxLWE6p8nIbrRA2nDOgNShFeGZp0sUzrgdJ52x7gGw+jzNBS21MJtCaxliCvX/1udGbLohxCbNMPOPqEi0TjxVmGFaYYVhhhmGFGYYVZhj/DyzTUa235PK4AAAAAElFTkSuQmCC"
    },
    {
        "id": "premier",
        "title": "PREMIER\n$219.19",
        "image": "iVBORw0KGgoAAAANSUhEUgAAAGwAAABnCAYAAADloacOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAvaSURBVHhe7Z19cBXHYcB/u3fv3r1PPX1LgGyMkYXMhy2DXTuAGTfBUNXUJLRATNrQNsauGex4nGLqBheSaUhIJ3amzaRxJ0nHaUIy6Uxn2jRtM9QenMR2neAE26pLEuzwZTsBJMST9L7udvvHexBJCGwQT2I9+9PsaPRu93bf/m73du9uT0JrrQEKJc2vT2lOZBUnhzTZvCZX1BQDTaiwXCaIlw+X9OHjit5BRVNaUp+U1MQFKV8Q8wSeK3Dk6GSWyUL8cH9Rt9U7tGasFRMQpaDcJVrMwDYrw7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDDGdQNzyl/cw6lSCUeA1mL0ZksFIaCkNa3RGAf++gujN18Q4xLW+PDdnCwWyiW66L28+xEChFJMjSV5bccXR2++IMbVJQoBovJT/sOGMUOlfsQl6ITGJcwy8VhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFVag8UH1eLofKmpAySCAixJiZico2Z/SGCUQAUThvGRzAm6gKOw9Vz98FpAqJFPK4Wp91FEe1JlLMI1WAO2rbuRBAoiJ59P4uFAG4WuMPnsQp5YmMjgBEgIgK8YdO4WpV/Uo7D1XN2wWUCpmXyrDiqmvIeB4acBGgNUkhSDgO3Ve2c2OmEa1CPICxVkBphUCD1mg0+VIRpRRaV15IfI40I9ZBDT9gtEJS/jsKfHzZKm6f3k4YlogLUU6nFQ6aSBgwv7aB+xcvY3o0hn86rxH7GyP/KlA1YRKocxwiJ46yddn72fXn2/h89+8jet+i0XFoclyG+o+zdckyvrV5O59cuRZ54igNjst0x2GKFDhoJOAJ6HBd6oSgTQqudlwWT72SmyI+s12XODDNcZgmJU6lEh3KaeqFRFTK0+FI2oWmQ2iucV1qhAQVEk0kWbVkKe+ZMQvyQySEJC0kHa7LLClpCvIsvaaTLWvWM7uunlQYEEHT4Tq0C02n1FzhuNWrzGFUNQ8BoEo01dXRmz3FrXO7mN3YSr5UwFEB7fE4d968mOP9J6lP16C0QqNpjfs0+3FiSuGhSSBoSyZodl3qpeB9HbP4+j0PsjjVyFWZFCnp0Oh7NPkxfB0SBWJCMC0Zpy4SIao1Cs3MTIoFrY3c0NrIlISPVIqYdBgczPKJb3yFJ/Y+i06kKaqAQliiIRals6GGtoSHDIsAhFqjBKRyQ7TEo8xvaWBuQw0ZV5IIg+pWaDWFqdO9hJDUp2vY+4v9DJYKbP29uxCD/ZSyx9m8Yh1DpSLf/79XSMTihBGfGtdlx5qP8NBt3TgDvcTDkHk1Gf7hz7ZwY0stt3fO4eEVd1GXSvPH6/+Ej//BR7g2neGR7tU8svz9qL63SKOZGU/wlY1/SXfnXErFHFdHY3z6j+5n69qNbF93P1/duJUNN99KJAyJR6M8vOpDzL/iKrQKSUmH7Uvv5GubtrJz/cd44qM7+MCSbgCkkPQVC2z93VV8ccNm7l3+QR5ZvZGvbniIRVPbqNVhVbvHqgkTQBGF8lMk4gl+8noPz7z0Y1Yuuo2rG6cwvXEaq5cs5d+ff4ZXjxwg4ccgGicCNGVqScfjSBXiaI0vIzTX1uNnprJzz3/xO1/+PAP5PPfu2MDCx7bz+ok3aK2tozaZRoTlNFEhaalvJO55NEiHUhAwf8uHuWH1HK6b08nTL/6I1TcupC4cQjouTZkMjbEEIjfA+zrnsXFpN4//yy5mbr2Pu594DFdWqmrwTTYvuJ5NK1az7bG/YfmaJdxyUxdhKeDB21fiKcUML1o1aVUT5gIFpRCJDMlYjNxQL7ue/R5hGLDy2nms7JxHrpDj757+Lnkt8KNRUn4CVACUl+IiJQyfDmgN8TQ3p2sRgJgymwX1LSAr40uhQQoQ5XTlKhMMhQFX1jfwjY2f5IdP/phnnn+BW6/rwnMjOI5b3q8QuEJA71Hu7JzHc6+8xNe+/2066ls5cKSHL31nF6AJ4k20z/otSkHAhnV/yO5//gHffWoP8ZhP3IuSpERUVK1aqydMApEwpDOVIRrxyIsk/33wlzz3yj5W/HY3y5cs45tPfY9D2T6KYYjnecxMpAiCgFBpEr7PYPYo2VNv4EmB0ppQ/aa70Vqjs4d5rZAj1FBSimQ0RrHvMP3ZY/iECDRKa7JonvzTB2ibOpVPfPlxHt2yhb/9n2fKBVVhuTvQuixYOhSDAC/iIXI53ijk6C8WiUf9cvwwQAXlhfif+foTbH98Gzv+aRsPfm4TD/3jpzkhYxws5Strmy89VRPmCHDDEjNrahEC8rkBpiRqWPvtJ7mqvolMxGP7f+xiRm0zhaEBHCFoS2XYPzTIy786yqLrF/DwHfdy38IV7Fx/H0orSmEIEY+fDfSTiMVYs+SD3NrYSigke4/8kq6Oa9m69mOsu34xj6/fBICQEkoBvf19zGho5q7lH6B73VrumN6OlLIy7BdE3EhZWN0V/P2LzzHv6na+tGkn721pY/PydXx01YcBgadK7H5+D66UfOqeh5jVtZCmpi5u6bqDTFM7g0IwVJ3eEADn0Ue3bRv94Tvls7v/jXwYjnk0OQKECmlL1zGloZF//ekL9OVz9B47QjoaZ3fPPp4/epioF0U6DnXpWvbs7+HQYJZDhw9Rm0yx6NrrmDplGrv3PsfhwQGe/cWrFHJ53uw7RgzBwjldzL1iOk/1/JSeg6+RiPosmTefjitn8ML+l/l57wleeP3nvHayly/86Ae0AA3NLdQ2txA4kp8cfJ3dB/aTRzCjtoH//FkPBwez9J46ya+P/YpFs69jWddNNDU2s+d/9/HWQJbvvPoqTx85yIs9LzG9uZX3zOnils651Dc2s+/oIQ72Hqc4qj4EINCkIx4PvPeOEdsulHG9p6Npy92cLBSHnS9+w+m5TxRICujTmgCBh8AJiigh0E6EIhqJxgNyunyZKh6GFFVIWyzGsTAkMnSKY34SKQQKQQyQQYn6qI8LHAwD4kpBGNASS5BVimCon2PRRPm8VO7zqMsPctKJUHTcMweZEOVWprU+8/qKGBAt5ol7Ps3RKG8WC+SKeYoRnyE0MQSxoISjSiRjKXwpeKtYIqcUBccZsy6EVkyLJTjwqUl8T8f50JWhfQg4wkFWsiqgUREP5UQoUD5vuEiS0sEVggAYcCSe51NU4AtJfyxNRrq4QqKBHKAj5S4srzUhggEpCTyfotZIIRjwU9RIh4iQhECIoN9PEvV86p0I9Y5LWjqVo1+QqcTVQB5N1vNR0qE/CEBIcl6MuJQ4CPLAKddlMJog1JpcqHEdh8Bxz5J1qalaCxtBZRR2fsrnkpEfqcooUTDmf8TSupxu+KiskkaUL2SNoNzOhjNGnsM5s//TrVSdfYyfvjRWaZ1jYUQLG8E5vshIzo5T7q7OIQsQQlTiDP9MjimLs2QxZp4jEJUpwpl4Y1SXkGemERPBxLSwtyEOVAbNlx19Y4q+MMxrYedBAiUEOXEZBsqT9vPdJ5toJrWFuZWwppDltvwJlJCIiy/OJUQgUATSY2eyhQNClq+Njo72DrmULWxShZ2+y/tI9g3WnehBSQ+hw9HRJgGB1CF5L8OHWm9gX2Wkea5z6dvxrhEmKy1seVBgQVhClWdCk87psWOI4kkvwaHKcP9iviPvJmFUvoyDwBFvP8qeMIaVo1i5IXqxrYtLLGzSBx0akGhcrXBR5d+THSrlcCpzrPHIutRMujCAIjCIuOzC0Dnmc5PJZSHM8s6xwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMMYl7PRThMKGtw2M47nG4YxLWE6p8nIbrRA2nDOgNShFeGZp0sUzrgdJ52x7gGw+jzNBS21MJtCaxliCvX/1udGbLohxCbNMPOPqEi0TjxVmGFaYYVhhhmGFGYYVZhj/DyzTUa235PK4AAAAAElFTkSuQmCC"
    },
    {
        "id": "annual_lite",
        "title": "ANNUAL LITE\n$1,826.57",
        "image": "iVBORw0KGgoAAAANSUhEUgAAAGwAAABnCAYAAADloacOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAvaSURBVHhe7Z19cBXHYcB/u3fv3r1PPX1LgGyMkYXMhy2DXTuAGTfBUNXUJLRATNrQNsauGex4nGLqBheSaUhIJ3amzaRxJ0nHaUIy6Uxn2jRtM9QenMR2neAE26pLEuzwZTsBJMST9L7udvvHexBJCGwQT2I9+9PsaPRu93bf/m73du9uT0JrrQEKJc2vT2lOZBUnhzTZvCZX1BQDTaiwXCaIlw+X9OHjit5BRVNaUp+U1MQFKV8Q8wSeK3Dk6GSWyUL8cH9Rt9U7tGasFRMQpaDcJVrMwDYrw7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDDGdQNzyl/cw6lSCUeA1mL0ZksFIaCkNa3RGAf++gujN18Q4xLW+PDdnCwWyiW66L28+xEChFJMjSV5bccXR2++IMbVJQoBovJT/sOGMUOlfsQl6ITGJcwy8VhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFVag8UH1eLofKmpAySCAixJiZico2Z/SGCUQAUThvGRzAm6gKOw9Vz98FpAqJFPK4Wp91FEe1JlLMI1WAO2rbuRBAoiJ59P4uFAG4WuMPnsQp5YmMjgBEgIgK8YdO4WpV/Uo7D1XN2wWUCpmXyrDiqmvIeB4acBGgNUkhSDgO3Ve2c2OmEa1CPICxVkBphUCD1mg0+VIRpRRaV15IfI40I9ZBDT9gtEJS/jsKfHzZKm6f3k4YlogLUU6nFQ6aSBgwv7aB+xcvY3o0hn86rxH7GyP/KlA1YRKocxwiJ46yddn72fXn2/h89+8jet+i0XFoclyG+o+zdckyvrV5O59cuRZ54igNjst0x2GKFDhoJOAJ6HBd6oSgTQqudlwWT72SmyI+s12XODDNcZgmJU6lEh3KaeqFRFTK0+FI2oWmQ2iucV1qhAQVEk0kWbVkKe+ZMQvyQySEJC0kHa7LLClpCvIsvaaTLWvWM7uunlQYEEHT4Tq0C02n1FzhuNWrzGFUNQ8BoEo01dXRmz3FrXO7mN3YSr5UwFEB7fE4d968mOP9J6lP16C0QqNpjfs0+3FiSuGhSSBoSyZodl3qpeB9HbP4+j0PsjjVyFWZFCnp0Oh7NPkxfB0SBWJCMC0Zpy4SIao1Cs3MTIoFrY3c0NrIlISPVIqYdBgczPKJb3yFJ/Y+i06kKaqAQliiIRals6GGtoSHDIsAhFqjBKRyQ7TEo8xvaWBuQw0ZV5IIg+pWaDWFqdO9hJDUp2vY+4v9DJYKbP29uxCD/ZSyx9m8Yh1DpSLf/79XSMTihBGfGtdlx5qP8NBt3TgDvcTDkHk1Gf7hz7ZwY0stt3fO4eEVd1GXSvPH6/+Ej//BR7g2neGR7tU8svz9qL63SKOZGU/wlY1/SXfnXErFHFdHY3z6j+5n69qNbF93P1/duJUNN99KJAyJR6M8vOpDzL/iKrQKSUmH7Uvv5GubtrJz/cd44qM7+MCSbgCkkPQVC2z93VV8ccNm7l3+QR5ZvZGvbniIRVPbqNVhVbvHqgkTQBGF8lMk4gl+8noPz7z0Y1Yuuo2rG6cwvXEaq5cs5d+ff4ZXjxwg4ccgGicCNGVqScfjSBXiaI0vIzTX1uNnprJzz3/xO1/+PAP5PPfu2MDCx7bz+ok3aK2tozaZRoTlNFEhaalvJO55NEiHUhAwf8uHuWH1HK6b08nTL/6I1TcupC4cQjouTZkMjbEEIjfA+zrnsXFpN4//yy5mbr2Pu594DFdWqmrwTTYvuJ5NK1az7bG/YfmaJdxyUxdhKeDB21fiKcUML1o1aVUT5gIFpRCJDMlYjNxQL7ue/R5hGLDy2nms7JxHrpDj757+Lnkt8KNRUn4CVACUl+IiJQyfDmgN8TQ3p2sRgJgymwX1LSAr40uhQQoQ5XTlKhMMhQFX1jfwjY2f5IdP/phnnn+BW6/rwnMjOI5b3q8QuEJA71Hu7JzHc6+8xNe+/2066ls5cKSHL31nF6AJ4k20z/otSkHAhnV/yO5//gHffWoP8ZhP3IuSpERUVK1aqydMApEwpDOVIRrxyIsk/33wlzz3yj5W/HY3y5cs45tPfY9D2T6KYYjnecxMpAiCgFBpEr7PYPYo2VNv4EmB0ppQ/aa70Vqjs4d5rZAj1FBSimQ0RrHvMP3ZY/iECDRKa7JonvzTB2ibOpVPfPlxHt2yhb/9n2fKBVVhuTvQuixYOhSDAC/iIXI53ijk6C8WiUf9cvwwQAXlhfif+foTbH98Gzv+aRsPfm4TD/3jpzkhYxws5Strmy89VRPmCHDDEjNrahEC8rkBpiRqWPvtJ7mqvolMxGP7f+xiRm0zhaEBHCFoS2XYPzTIy786yqLrF/DwHfdy38IV7Fx/H0orSmEIEY+fDfSTiMVYs+SD3NrYSigke4/8kq6Oa9m69mOsu34xj6/fBICQEkoBvf19zGho5q7lH6B73VrumN6OlLIy7BdE3EhZWN0V/P2LzzHv6na+tGkn721pY/PydXx01YcBgadK7H5+D66UfOqeh5jVtZCmpi5u6bqDTFM7g0IwVJ3eEADn0Ue3bRv94Tvls7v/jXwYjnk0OQKECmlL1zGloZF//ekL9OVz9B47QjoaZ3fPPp4/epioF0U6DnXpWvbs7+HQYJZDhw9Rm0yx6NrrmDplGrv3PsfhwQGe/cWrFHJ53uw7RgzBwjldzL1iOk/1/JSeg6+RiPosmTefjitn8ML+l/l57wleeP3nvHayly/86Ae0AA3NLdQ2txA4kp8cfJ3dB/aTRzCjtoH//FkPBwez9J46ya+P/YpFs69jWddNNDU2s+d/9/HWQJbvvPoqTx85yIs9LzG9uZX3zOnils651Dc2s+/oIQ72Hqc4qj4EINCkIx4PvPeOEdsulHG9p6Npy92cLBSHnS9+w+m5TxRICujTmgCBh8AJiigh0E6EIhqJxgNyunyZKh6GFFVIWyzGsTAkMnSKY34SKQQKQQyQQYn6qI8LHAwD4kpBGNASS5BVimCon2PRRPm8VO7zqMsPctKJUHTcMweZEOVWprU+8/qKGBAt5ol7Ps3RKG8WC+SKeYoRnyE0MQSxoISjSiRjKXwpeKtYIqcUBccZsy6EVkyLJTjwqUl8T8f50JWhfQg4wkFWsiqgUREP5UQoUD5vuEiS0sEVggAYcCSe51NU4AtJfyxNRrq4QqKBHKAj5S4srzUhggEpCTyfotZIIRjwU9RIh4iQhECIoN9PEvV86p0I9Y5LWjqVo1+QqcTVQB5N1vNR0qE/CEBIcl6MuJQ4CPLAKddlMJog1JpcqHEdh8Bxz5J1qalaCxtBZRR2fsrnkpEfqcooUTDmf8TSupxu+KiskkaUL2SNoNzOhjNGnsM5s//TrVSdfYyfvjRWaZ1jYUQLG8E5vshIzo5T7q7OIQsQQlTiDP9MjimLs2QxZp4jEJUpwpl4Y1SXkGemERPBxLSwtyEOVAbNlx19Y4q+MMxrYedBAiUEOXEZBsqT9vPdJ5toJrWFuZWwppDltvwJlJCIiy/OJUQgUATSY2eyhQNClq+Njo72DrmULWxShZ2+y/tI9g3WnehBSQ+hw9HRJgGB1CF5L8OHWm9gX2Wkea5z6dvxrhEmKy1seVBgQVhClWdCk87psWOI4kkvwaHKcP9iviPvJmFUvoyDwBFvP8qeMIaVo1i5IXqxrYtLLGzSBx0akGhcrXBR5d+THSrlcCpzrPHIutRMujCAIjCIuOzC0Dnmc5PJZSHM8s6xwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMMYl7PRThMKGtw2M47nG4YxLWE6p8nIbrRA2nDOgNShFeGZp0sUzrgdJ52x7gGw+jzNBS21MJtCaxliCvX/1udGbLohxCbNMPOPqEi0TjxVmGFaYYVhhhmGFGYYVZhj/DyzTUa235PK4AAAAAElFTkSuQmCC"
    },
    {
        "id": "annual",
        "title": "ANNUAL\n$2,191.88",
        "image": "iVBORw0KGgoAAAANSUhEUgAAAGwAAABnCAYAAADloacOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAvaSURBVHhe7Z19cBXHYcB/u3fv3r1PPX1LgGyMkYXMhy2DXTuAGTfBUNXUJLRATNrQNsauGex4nGLqBheSaUhIJ3amzaRxJ0nHaUIy6Uxn2jRtM9QenMR2neAE26pLEuzwZTsBJMST9L7udvvHexBJCGwQT2I9+9PsaPRu93bf/m73du9uT0JrrQEKJc2vT2lOZBUnhzTZvCZX1BQDTaiwXCaIlw+X9OHjit5BRVNaUp+U1MQFKV8Q8wSeK3Dk6GSWyUL8cH9Rt9U7tGasFRMQpaDcJVrMwDYrw7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDDGdQNzyl/cw6lSCUeA1mL0ZksFIaCkNa3RGAf++gujN18Q4xLW+PDdnCwWyiW66L28+xEChFJMjSV5bccXR2++IMbVJQoBovJT/sOGMUOlfsQl6ITGJcwy8VhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFGYYVZhhWmGFYYYZhhRmGFWYYVphhWGGGYYUZhhVmGFaYYVhhhmGFVag8UH1eLofKmpAySCAixJiZico2Z/SGCUQAUThvGRzAm6gKOw9Vz98FpAqJFPK4Wp91FEe1JlLMI1WAO2rbuRBAoiJ59P4uFAG4WuMPnsQp5YmMjgBEgIgK8YdO4WpV/Uo7D1XN2wWUCpmXyrDiqmvIeB4acBGgNUkhSDgO3Ve2c2OmEa1CPICxVkBphUCD1mg0+VIRpRRaV15IfI40I9ZBDT9gtEJS/jsKfHzZKm6f3k4YlogLUU6nFQ6aSBgwv7aB+xcvY3o0hn86rxH7GyP/KlA1YRKocxwiJ46yddn72fXn2/h89+8jet+i0XFoclyG+o+zdckyvrV5O59cuRZ54igNjst0x2GKFDhoJOAJ6HBd6oSgTQqudlwWT72SmyI+s12XODDNcZgmJU6lEh3KaeqFRFTK0+FI2oWmQ2iucV1qhAQVEk0kWbVkKe+ZMQvyQySEJC0kHa7LLClpCvIsvaaTLWvWM7uunlQYEEHT4Tq0C02n1FzhuNWrzGFUNQ8BoEo01dXRmz3FrXO7mN3YSr5UwFEB7fE4d968mOP9J6lP16C0QqNpjfs0+3FiSuGhSSBoSyZodl3qpeB9HbP4+j0PsjjVyFWZFCnp0Oh7NPkxfB0SBWJCMC0Zpy4SIao1Cs3MTIoFrY3c0NrIlISPVIqYdBgczPKJb3yFJ/Y+i06kKaqAQliiIRals6GGtoSHDIsAhFqjBKRyQ7TEo8xvaWBuQw0ZV5IIg+pWaDWFqdO9hJDUp2vY+4v9DJYKbP29uxCD/ZSyx9m8Yh1DpSLf/79XSMTihBGfGtdlx5qP8NBt3TgDvcTDkHk1Gf7hz7ZwY0stt3fO4eEVd1GXSvPH6/+Ej//BR7g2neGR7tU8svz9qL63SKOZGU/wlY1/SXfnXErFHFdHY3z6j+5n69qNbF93P1/duJUNN99KJAyJR6M8vOpDzL/iKrQKSUmH7Uvv5GubtrJz/cd44qM7+MCSbgCkkPQVC2z93VV8ccNm7l3+QR5ZvZGvbniIRVPbqNVhVbvHqgkTQBGF8lMk4gl+8noPz7z0Y1Yuuo2rG6cwvXEaq5cs5d+ff4ZXjxwg4ccgGicCNGVqScfjSBXiaI0vIzTX1uNnprJzz3/xO1/+PAP5PPfu2MDCx7bz+ok3aK2tozaZRoTlNFEhaalvJO55NEiHUhAwf8uHuWH1HK6b08nTL/6I1TcupC4cQjouTZkMjbEEIjfA+zrnsXFpN4//yy5mbr2Pu594DFdWqmrwTTYvuJ5NK1az7bG/YfmaJdxyUxdhKeDB21fiKcUML1o1aVUT5gIFpRCJDMlYjNxQL7ue/R5hGLDy2nms7JxHrpDj757+Lnkt8KNRUn4CVACUl+IiJQyfDmgN8TQ3p2sRgJgymwX1LSAr40uhQQoQ5XTlKhMMhQFX1jfwjY2f5IdP/phnnn+BW6/rwnMjOI5b3q8QuEJA71Hu7JzHc6+8xNe+/2066ls5cKSHL31nF6AJ4k20z/otSkHAhnV/yO5//gHffWoP8ZhP3IuSpERUVK1aqydMApEwpDOVIRrxyIsk/33wlzz3yj5W/HY3y5cs45tPfY9D2T6KYYjnecxMpAiCgFBpEr7PYPYo2VNv4EmB0ppQ/aa70Vqjs4d5rZAj1FBSimQ0RrHvMP3ZY/iECDRKa7JonvzTB2ibOpVPfPlxHt2yhb/9n2fKBVVhuTvQuixYOhSDAC/iIXI53ijk6C8WiUf9cvwwQAXlhfif+foTbH98Gzv+aRsPfm4TD/3jpzkhYxws5Strmy89VRPmCHDDEjNrahEC8rkBpiRqWPvtJ7mqvolMxGP7f+xiRm0zhaEBHCFoS2XYPzTIy786yqLrF/DwHfdy38IV7Fx/H0orSmEIEY+fDfSTiMVYs+SD3NrYSigke4/8kq6Oa9m69mOsu34xj6/fBICQEkoBvf19zGho5q7lH6B73VrumN6OlLIy7BdE3EhZWN0V/P2LzzHv6na+tGkn721pY/PydXx01YcBgadK7H5+D66UfOqeh5jVtZCmpi5u6bqDTFM7g0IwVJ3eEADn0Ue3bRv94Tvls7v/jXwYjnk0OQKECmlL1zGloZF//ekL9OVz9B47QjoaZ3fPPp4/epioF0U6DnXpWvbs7+HQYJZDhw9Rm0yx6NrrmDplGrv3PsfhwQGe/cWrFHJ53uw7RgzBwjldzL1iOk/1/JSeg6+RiPosmTefjitn8ML+l/l57wleeP3nvHayly/86Ae0AA3NLdQ2txA4kp8cfJ3dB/aTRzCjtoH//FkPBwez9J46ya+P/YpFs69jWddNNDU2s+d/9/HWQJbvvPoqTx85yIs9LzG9uZX3zOnils651Dc2s+/oIQ72Hqc4qj4EINCkIx4PvPeOEdsulHG9p6Npy92cLBSHnS9+w+m5TxRICujTmgCBh8AJiigh0E6EIhqJxgNyunyZKh6GFFVIWyzGsTAkMnSKY34SKQQKQQyQQYn6qI8LHAwD4kpBGNASS5BVimCon2PRRPm8VO7zqMsPctKJUHTcMweZEOVWprU+8/qKGBAt5ol7Ps3RKG8WC+SKeYoRnyE0MQSxoISjSiRjKXwpeKtYIqcUBccZsy6EVkyLJTjwqUl8T8f50JWhfQg4wkFWsiqgUREP5UQoUD5vuEiS0sEVggAYcCSe51NU4AtJfyxNRrq4QqKBHKAj5S4srzUhggEpCTyfotZIIRjwU9RIh4iQhECIoN9PEvV86p0I9Y5LWjqVo1+QqcTVQB5N1vNR0qE/CEBIcl6MuJQ4CPLAKddlMJog1JpcqHEdh8Bxz5J1qalaCxtBZRR2fsrnkpEfqcooUTDmf8TSupxu+KiskkaUL2SNoNzOhjNGnsM5s//TrVSdfYyfvjRWaZ1jYUQLG8E5vshIzo5T7q7OIQsQQlTiDP9MjimLs2QxZp4jEJUpwpl4Y1SXkGemERPBxLSwtyEOVAbNlx19Y4q+MMxrYedBAiUEOXEZBsqT9vPdJ5toJrWFuZWwppDltvwJlJCIiy/OJUQgUATSY2eyhQNClq+Njo72DrmULWxShZ2+y/tI9g3WnehBSQ+hw9HRJgGB1CF5L8OHWm9gX2Wkea5z6dvxrhEmKy1seVBgQVhClWdCk87psWOI4kkvwaHKcP9iviPvJmFUvoyDwBFvP8qeMIaVo1i5IXqxrYtLLGzSBx0akGhcrXBR5d+THSrlcCpzrPHIutRMujCAIjCIuOzC0Dnmc5PJZSHM8s6xwgzDCjMMK8wwrDDDsMIMwwozDCvMMKwww7DCDMMKMwwrzDCsMMOwwgzDCjMMK8wwrDDDsMIMwwozDCvMMMYl7PRThMKGtw2M47nG4YxLWE6p8nIbrRA2nDOgNShFeGZp0sUzrgdJ52x7gGw+jzNBS21MJtCaxliCvX/1udGbLohxCbNMPOPqEi0TjxVmGFaYYVhhhmGFGYYVZhj/DyzTUa235PK4AAAAAElFTkSuQmCC"
    }
]




@schengen_travel_insurance_router.post("/")
async def travel_insurance(body: dict = Body()):
    encrypted_flow_data_b64 = body["encrypted_flow_data"]
    encrypted_aes_key_b64 = body["encrypted_aes_key"]
    initial_vector_b64 = body["initial_vector"]

    decrypted_data, aes_key, iv = decrypt_request(
        encrypted_flow_data_b64,
        encrypted_aes_key_b64,
        initial_vector_b64,
        PHONE_NUMBER_PRIVATE_KEY,
    )

    print(decrypted_data)

    if decrypted_data["action"] == "ping":
        response = {"data": {"status": "active"}}
    elif decrypted_data["action"] == "INIT":
        response = {"screen": "Travel_Insurance_for_Schengen_Visa", "data": {"message": "success"}}
    elif decrypted_data["data"]["trigger"] == "choose_country_selected":
        if decrypted_data["data"]["choose_country"] == "for_sri_lanka":
            response = {
                "screen":"Travel_Insurance_for_sri_lanka",
                "data":{
                    "age_morethan_74_visible":False,
                    "age_morethan_79_visible":False
                }
            }
        elif decrypted_data["data"]["choose_country"] == "for_nepal":
             response = {
                "screen":"Travel_Insurance_for_nepal",
                "data":{
                    "age_morethan_74_visible":False,
                    "age_morethan_79_visible":False
                }
            }
        elif decrypted_data["data"]["choose_country"] == "for_india":
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "details_visible_required":False,
                    "details_visible_required_two":False,
                    "your_trip_details_visible":False
                }
            }              
    elif decrypted_data["data"]["trigger"] == "travelers_selected":
        response = {
            "screen":"Travel_Insurance_for_sri_lanka",
            "data":{
                "age_morethan_74_visible":True,
                "age_morethan_79_visible":False
            }
        }
    elif decrypted_data["data"]["trigger"] == "travelers_selected_for_nepal":
         response = {
            "screen":"Travel_Insurance_for_nepal",
            "data":{
                "age_morethan_74_visible":True,
                "age_morethan_79_visible":False
            }
        }   
    elif decrypted_data["data"]["trigger"] == "age_morethan_74_selected":
        if decrypted_data["data"]["age_morethan_74"] == "yes":
            response = {
                "screen":"Travel_Insurance_for_sri_lanka",
                "data":{
                    "age_morethan_79_visible":True
                }
            }
        else:
            response = {
                "screen":"Travel_Insurance_for_sri_lanka",
                "data":{
                    "age_morethan_79_visible":False
                }
            }
    elif decrypted_data["data"]["trigger"] == "nepal_age_morethan_74_selected":
        if decrypted_data["data"]["age_morethan_74"] == "yes":
            response = {
                "screen":"Travel_Insurance_for_nepal",
                "data":{
                    "age_morethan_79_visible":True
                }
            }
        else:
            response = {
                "screen":"Travel_Insurance_for_nepal",
                "data":{
                    "age_morethan_79_visible":False
                }
            }        
    elif decrypted_data["data"]["trigger"] == "Find_My_Insurance":
        decrypted_data["data"].pop("trigger")
        departure_country = decrypted_data["data"].get("departure_country")
        arrival_country = decrypted_data["data"].get("arrival_country")
        departure_date = decrypted_data["data"].get("departure_date")
        return_date = decrypted_data["data"].get("return_date")
        travelers = decrypted_data["data"].get("travelers")
        message = generate_insurance_message(departure_country,arrival_country,departure_date,return_date,travelers)
        response = {
            "screen":"Find_Insurance",
            "data":{
                "insurance_details_msg":message,
                "insurance_list":insurance_list,
                "select_insurance_link_visible":False
            }
        }
    elif decrypted_data["data"]["trigger"] == "insurance_list_selected":
        insurance_type = decrypted_data["data"]["insurance"]
        if insurance_type == "basic":
            second_message = get_insurance_guarantee_message(insurance_type)
            first_message = get_insurance_type_message(insurance_type)
            response = {
                "screen":"Find_Insurance",
                "data":{
                    "insurance_type_details_msg":first_message,
                    "insurance_type_details_second_msg":second_message,
                    "select_insurance_link_visible":True
                }
            }
        elif insurance_type == "premier_lite":
            second_message = get_insurance_guarantee_message(insurance_type)
            first_message = get_insurance_type_message(insurance_type)
            response = {
                "screen":"Find_Insurance",
                "data":{
                    "insurance_type_details_msg":first_message,
                    "insurance_type_details_second_msg":second_message,
                    "select_insurance_link_visible":True
                }
            }        
        elif insurance_type == "premier":
            second_message = get_insurance_guarantee_message(insurance_type)
            first_message = get_insurance_type_message(insurance_type)
            response = {
                "screen":"Find_Insurance",
                "data":{
                    "insurance_type_details_msg":first_message,
                    "insurance_type_details_second_msg":second_message,
                    "select_insurance_link_visible":True
                }
            }
        elif insurance_type == "annual_lite":
            second_message = get_insurance_guarantee_message(insurance_type)
            first_message = get_insurance_type_message(insurance_type)
            response = {
                "screen":"Find_Insurance",
                "data":{
                    "insurance_type_details_msg":first_message,
                    "insurance_type_details_second_msg":second_message,
                    "select_insurance_link_visible":True
                }
            }
        elif insurance_type == "annual":
            second_message = get_insurance_guarantee_message(insurance_type)
            first_message = get_insurance_type_message(insurance_type)
            response = {
                "screen":"Find_Insurance",
                "data":{
                    "insurance_type_details_msg":first_message,
                    "insurance_type_details_second_msg":second_message,
                    "select_insurance_link_visible":True
                }
            }
    elif decrypted_data["data"]["trigger"] == "Insurance_Selected":
        decrypted_data["data"].pop("trigger")
        response = {
            "screen":"Traveler_details",
            "data":{
            "store_data":decrypted_data["data"],
            "message":"success"
            }
        }
    elif decrypted_data["data"]["trigger"] == "Traveler_details_selected":
        decrypted_data["data"].pop("trigger")
        store_data = decrypted_data["data"].get("store_data",{})
        message = build_insurance_card_message(store_data)
        response = {
            "screen":"Traveler_details_summary",
            "data":{
                "summary_of_insurance":message
            }
        }   
    elif decrypted_data["data"]["trigger"] == "insurance_type_for_india_selected":
        choose_insurance_type = decrypted_data["data"]["choose_insurance_type"]
        if choose_insurance_type == "Reliance Travel Insurance":
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "your_trip_details_visible":True,
                    "details_visible_required":False,
                    "details_visible_required_two":False
                }
            }
        elif choose_insurance_type == "TATA AIG Insurance":
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "your_trip_details_visible":True,
                    "details_visible_required":False,
                    "details_visible_required_two":False
                }
            }    
    elif decrypted_data["data"]["trigger"] == "Travelers_Selected":
        traveler = decrypted_data["data"]["travelers"]
        if traveler == "1":
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "details_visible_required":True,
                    "details_visible_required_two":False
                }
            }
        elif traveler == "2":
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "details_visible_required":True,
                    "details_visible_required_two":True
                }
            }
        else:
            response = {
                "screen":"Travel_Insurance_for_india",
                "data":{
                    "details_visible_required":True,
                    "details_visible_required_two":False
                }
            }    
    elif decrypted_data["data"]["trigger"] == "Trip_Details_Selected":
        decrypted_data["data"].pop("trigger")
        all_data = decrypted_data["data"]
        start_date = all_data.get("start_date","")
        end_date = all_data.get("end_date","")
        travelerss = all_data.get("travelers","")
        messagees = generate_travel_guidelines_message(start_date,end_date,travelerss)
        print("🥴🥴🥴🥴🥴🥴",all_data)
        response = {
            "screen":"Reliance_Travel_Insurance_Summary",
            "data":{
                "summary_details":messagees
            }
        }






    encrypted_response = encrypt_response(response, aes_key, iv)
    return PlainTextResponse(content=encrypted_response, media_type="text/plain")
