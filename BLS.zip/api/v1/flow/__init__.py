from fastapi import APIRouter
from .book_appoinment import book_appoinment_router
from .cancel_appointment import cancel_appoinment_router
from .customer_experience import customer_experience_router
from .insurance_for_national_visa import insurance_for_national_visa_router
from .reprint_appointment import reprint_appoinment_router
from .insurance_for_schengen_visa import schengen_travel_insurance_router
from .travel_insurance_additional import additional_travel_insurance_router


flow_router = APIRouter()

flow_router.include_router(book_appoinment_router,prefix="/book")
flow_router.include_router(cancel_appoinment_router,prefix="/cancel")
flow_router.include_router(customer_experience_router,prefix="/customer-experience")
flow_router.include_router(insurance_for_national_visa_router,prefix="/national-visa-insurance")
flow_router.include_router(schengen_travel_insurance_router,prefix="/schengen-visa-insurance")
flow_router.include_router(additional_travel_insurance_router,prefix="/additional-travel-insurance")
flow_router.include_router(reprint_appoinment_router,prefix="/reprint")
