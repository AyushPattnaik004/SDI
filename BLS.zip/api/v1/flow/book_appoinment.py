from fastapi import APIRouter, Body
from fastapi.responses import PlainTextResponse

from utils.fb_utils import decrypt_request, encrypt_response
from core.keys import PHONE_NUMBER_PRIVATE_KEY
from services.bls_book_apis import BLS_Book_API
import json

book_appoinment_router = APIRouter()
api = BLS_Book_API()


@book_appoinment_router.post("/")
async def book_appoinment(body: dict = Body()):
    encrypted_flow_data_b64 = body["encrypted_flow_data"]
    encrypted_aes_key_b64 = body["encrypted_aes_key"]
    initial_vector_b64 = body["initial_vector"]

    decrypted_data, aes_key, iv = decrypt_request(
        encrypted_flow_data_b64,
        encrypted_aes_key_b64,
        initial_vector_b64,
        PHONE_NUMBER_PRIVATE_KEY,
    )

    print(decrypted_data)

    if decrypted_data["action"] == "ping":
        response = {"data": {"status": "active"}}
    elif decrypted_data["action"] == "INIT":
        country_list = [{"id":"india","title":"India"}]
        country_list.extend(api.country_list)
        response = {"screen": "USER_REGISTRATION", "data": {"message": "success","country_details": country_list}}
    elif decrypted_data["data"]["trigger"] == "USER_REGISTRATION_SELECTED":
        response = {
            "screen": "location_and_visa",
            "data": {
                "country_details": api.country_list,
                "visa_center_details": api.visa_center,
                "nationality_details": api.nationality,
                "visa_type_details": api.visa_type,
                "visa_subcategory_details": api.visa_subcategory,
            },
        }
    elif decrypted_data["data"]["trigger"] == "location_and_visa_selected":
        response = {"screen": "APPLICANT_DETAILS_FORM", "data": {"message": "success"}}
    elif decrypted_data["data"]["trigger"] == "APPLICANT_DETAILS_FORM_SELECTED":
        response = {
            "screen": "DOCUMENT_UPLOAD",
            "data": {
                "availble_dates_list": api.get_available_dates(),
                "time_slot_list": api.time_slot,
                "doc_value": api.document_list[0] if api.document_list else "",
                "upload_document_visible": True,
                "current_document_index": ["0"],
                "document_msg":False,
                "footerEnabled":False,
                "upload_text":[
                    "**PASSPORT**: Need to upload",
                    "**PHOTO**: Need to upload",
                    "**AADHAAR CARD**: Need to upload",
                    "**TRAVEL INSURANCE**: Need to upload",
                    "**FLIGHT TICKET**: Need to upload"
                ]
            },
        }
    elif decrypted_data["data"]["trigger"] == "document_uploaded":
        current_index = int(
            decrypted_data["data"]["current_document_index"][0]
        )
        next_index = current_index + 1
        if next_index < len(api.document_list):
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "doc_value": api.document_list[next_index],
                    "current_document_index": [str(next_index)],
                    "upload_document_visible": True
                }
            }
        else:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "upload_document_visible": False,
                    "document_msg":True
                }
            }
        
        if "flight_ticket" in decrypted_data['data']:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "upload_document_visible": False,
                    "document_msg":True,
                    "footerEnabled":True,
                    "upload_text":[
                    "**PASSPORT**: UPLOADED SUCCESSFULLY",
                    "**PHOTO**: UPLOADED SUCCESSFULLY",
                    "**AADHAAR CARD**: UPLOADED SUCCESSFULLY",
                    "**TRAVEL INSURANCE**: UPLOADED SUCCESSFULLY",
                    "**FLIGHT TICKET**: UPLOADED SUCCESSFULLY"
                ]
                }
            }
        elif "insurance" in decrypted_data['data']:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "doc_value":"flight_ticket",
                    "upload_text":[
                    "**PASSPORT**: UPLOADED SUCCESSFULLY",
                    "**PHOTO**: UPLOADED SUCCESSFULLY",
                    "**AADHAAR CARD**: UPLOADED SUCCESSFULLY",
                    "**TRAVEL INSURANCE**: UPLOADED SUCCESSFULLY",
                    "**FLIGHT TICKET**: NEED TO UPLOAD"
                ]
                }
            }
        
        elif "aadhar" in decrypted_data['data']:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "doc_value":"insurance",
                    "upload_text":[
                    "**PASSPORT**: UPLOADED SUCCESSFULLY",
                    "**PHOTO**: UPLOADED SUCCESSFULLY",
                    "**AADHAAR CARD**: UPLOADED SUCCESSFULLY",
                    "**TRAVEL INSURANCE**: NEED TO UPLOAD",
                    "**FLIGHT TICKET**: NEED TO UPLOAD"
                ]
                }
            }
        
        elif "photo" in decrypted_data['data']:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "doc_value":"aadhar",
                    "upload_text":[
                    "**PASSPORT**: UPLOADED SUCCESSFULLY",
                    "**PHOTO**: UPLOADED SUCCESSFULLY",
                    "**AADHAAR CARD**: NEED TO UPLOAD",
                    "**TRAVEL INSURANCE**: NEED TO UPLOAD",
                    "**FLIGHT TICKET**: NEED TO UPLOAD"
                ]
                }
            }
        
        elif "passport" in decrypted_data['data']:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "doc_value":"photo",
                    "upload_text":[
                    "**PASSPORT**: UPLOADED SUCCESSFULLY",
                    "**PHOTO**: NEED TO UPLOAD",
                    "**AADHAAR CARD**: NEED TO UPLOAD",
                    "**TRAVEL INSURANCE**: NEED TO UPLOAD",
                    "**FLIGHT TICKET**: NEED TO UPLOAD"
                ]
                }
            }
        else:
            response = {
                "screen": "DOCUMENT_UPLOAD",
                "data": {
                    "error_message":"Upload document first"
                
                }
            }


    encrypted_response = encrypt_response(response, aes_key, iv)
    return PlainTextResponse(content=encrypted_response, media_type="text/plain")
