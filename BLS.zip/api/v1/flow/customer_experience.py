from fastapi import APIRouter, Body
from fastapi.responses import PlainTextResponse

from utils.fb_utils import decrypt_request, encrypt_response
from core.keys import PHONE_NUMBER_PRIVATE_KEY
import json

customer_experience_router = APIRouter()


@customer_experience_router.post("/")
async def customer_experience(body: dict = Body()):
    encrypted_flow_data_b64 = body["encrypted_flow_data"]
    encrypted_aes_key_b64 = body["encrypted_aes_key"]
    initial_vector_b64 = body["initial_vector"]

    decrypted_data, aes_key, iv = decrypt_request(
        encrypted_flow_data_b64,
        encrypted_aes_key_b64,
        initial_vector_b64,
        PHONE_NUMBER_PRIVATE_KEY,
    )

    print(decrypted_data)

    if decrypted_data["action"] == "ping":
        response = {"data": {"status": "active"}}
    elif decrypted_data["action"] == "INIT":
        response = {
            "screen": "WELCOME_SCREEN",
            "data": {}
        }
    elif decrypted_data["data"]["trigger"] == "feedback_type_selected":
        feedback_type = decrypted_data['data'].get("feedback_type")
        
        if feedback_type == "compliments":
            response = {
                "screen":"COMPLIMENT_SCREEN",
                "data":{}
            }
        elif feedback_type == "complaints":
            response = {
                "screen":"COMPLAINT_SCREEN",
                "data":{}
            }

           



    encrypted_response = encrypt_response(response, aes_key, iv)
    return PlainTextResponse(content=encrypted_response, media_type="text/plain")
