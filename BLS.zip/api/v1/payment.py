from fastapi import APIRouter, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import HTMLResponse
from utils.send_message import send_message
from models.bls_data_flow import BLSDataFlow

from core.db import BLS_DB
payment_app = APIRouter()



@payment_app.get("/confirm-payment-bls")
def pay(id:str,ref: str,mobile:str):
    db = BLS_DB()
    print('\n\n\nhereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
    message = f"""
Your booking is confirmed with ID: {ref} you will receive the appointment letter through sms or email.
"""

    send_message("interactive", "Your payment against booking was successful", None, [{"type":"order_status", "reference_id":ref, "order_status":"completed","order_description":"O.K"}], None, None,mobile, 'MESSAGE', "en", "919668972561")
    user_data_instance = db.query(BLSDataFlow).filter(BLSDataFlow.id == id)
    print(jsonable_encoder(user_data_instance.first()))
    user_data_instance.update({"status":"COMPLETE"})
    
    if user_data_instance.first() == "book_appointment":
        message = """
Please find attached your appointment confirmation letter for your upcoming visa application appointment 📄🛂

📅 Kindly verify all appointment details carefully before visiting the visa application centre.

⚠️ Important Reminders:
• Carry a printed copy of the appointment letter
• Bring your original passport and supporting documents
• Arrive at the centre at least 15 minutes before your appointment time

We wish you a smooth and hassle-free application experience 🌍✨
"""

        
        send_message('document', message, None, None, None, "https://citylyticsmain.in:11116/assets/appointment_letter.pdf", mobile, 'MESSAGE', 'en', '919668972561')
    else:
        send_message('text', message, None, None, None, None, mobile, 'MESSAGE', 'en', '919668972561')

    print(id)
    db.commit()
    db.close()
    html_content = f'''
                <!DOCTYPE html>
                <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>Redirect To Payment</title>
                </head>
                <body>
                    If not redirect automatically please <a id="payment_link" href="https://api.whatsapp.com/send/?phone=919668972561" > Click here </a>
                    <script>
                        document.getElementById("payment_link").click()
                    </script>
                </body>
                </html>
            '''

    return HTMLResponse(content=html_content)


@payment_app.get("/bls", response_class=HTMLResponse)
def payment_page(id:str,ref: str, mobile: str):
    return f"""
    <!DOCTYPE html>
<html>
<head>
    <title>BLS INTERNATIONAL | Payment</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            background: #f2f7ff;
            margin: 0;
            padding: 0;
        }}

        .header {{
            background: #0059b3;
            padding: 20px;
            text-align: center;
            color: white;
        }}

        .header img {{
            height: 60px;
        }}

        .container {{
            max-width: 450px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
        }}

        .label {{
            font-size: 18px;
            margin-bottom: 8px;
            color: #333;
        }}

        .value-box {{
            background: #e8f0ff;
            padding: 12px;
            font-size: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }}

        .pay-btn {{
            padding: 15px 40px;
            background: #28a745;
            color: white;
            border: none;
            font-size: 20px;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.3s;
        }}

        .pay-btn:hover {{
            background: #218838;
        }}

        .footer-logo {{
            margin-top: 25px;
            opacity: 0.8;
        }}

        .message {{
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }}
    </style>
</head>
<body>

    <div class="header">
        <h2>BLS INTERNATIONAL</h2>
    </div>

    <div class="container">
        <div class="label">Reference Number</div>
        <div class="value-box">{ref}</div>

        <div class="label">Mobile Number</div>
        <div class="value-box">{mobile}</div>

        <button class="pay-btn" onclick="payNow()">Pay Now 💳</button>

        <div id="response" class="message"></div>

    </div>

    <script>
    function payNow() {{
        window.location.href = `/api/v1/payment/confirm-payment-bls?id={id}&ref={ref}&mobile={mobile}`;
    }}
</script>

</body>
</html>
"""
