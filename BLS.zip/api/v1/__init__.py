from fastapi import APIRouter

from .flow import flow_router
from .payment import payment_app

v1_router = APIRouter()

v1_router.include_router(flow_router,prefix="/flow")
v1_router.include_router(payment_app, prefix="/payment")