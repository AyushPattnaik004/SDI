from .base import Base
from sqlalchemy.dialects.mysql import TEXT,JSON,BOOLEAN, INTEGER,TIMESTAMP
from sqlalchemy.dialects.postgresql import ARRAY,UUID
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime, timedelta
from sqlalchemy import  Uuid

class MasterData(Base):

    __tablename__ = "bls_master_table"

    number: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    language: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    passport_number: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    full_name: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    nationality: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    email_address: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    date_of_birth: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    created_at: Mapped[TIMESTAMP]= mapped_column(TIMESTAMP, nullable= True,default=datetime.now())