from .base import Base
from sqlalchemy.dialects.mysql import TEXT,JSON,BOOLEAN, INTEGER,TIMESTAMP
from sqlalchemy.dialects.postgresql import ARRAY,UUID
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime, timedelta
from sqlalchemy import  Uuid

class BLSData(Base):
    __tablename__ = "bls_user_state"

    number: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    status: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    service: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    step: Mapped[TEXT]= mapped_column(TEXT, nullable= True)
    user_data: Mapped[JSON]= mapped_column(JSON, nullable= True)
    created_at: Mapped[TIMESTAMP]= mapped_column(TIMESTAMP, nullable= True,default=datetime.now())