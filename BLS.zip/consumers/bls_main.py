import json
import requests
from pika import BlockingConnection, ConnectionParameters, PlainCredentials
from fastapi.encoders import jsonable_encoder
from pika.spec import Basic, BasicProperties
from pika.channel import Channel
from ulid import ULID
from datetime import datetime

from core.db import BLS_DB
from models.bls_data import BLSData
from models.master_data import MasterData

from utils.gemini_helper import process_message

from utils.send_message import send_message


import traceback

import random

from datetime import date, timedelta
import base64
import hashlib
import hmac
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad


class BLS:

    def __init__(self, queue: str = "bls", prefetch_count: int = 1) -> None:

        self.connection = BlockingConnection(ConnectionParameters(host="localhost"))
        # self.connection = BlockingConnection(ConnectionParameters("localhost"))
        self.queue_name = queue
        self.channel = self.connection.channel()
        self.prefetch_count = prefetch_count

        self.channel.queue_declare(self.queue_name, durable=True)

        self.channel.basic_qos(prefetch_count=self.prefetch_count)
        self.channel.basic_consume(
            queue=self.queue_name, on_message_callback=self.callback
        )

        self.channel.start_consuming()

    def callback(
        self,
        ch: Channel,
        method: Basic.Deliver,
        properties: BasicProperties,
        body: bytes,
    ):
        try:
            db = BLS_DB()
            chat = json.loads(body.decode())
            print(chat)
            chat_is = chat["entry"][0]["changes"][0]["value"]["messages"][0]
            sender: str = chat_is["from"]
            payload = None
            phone_number_id = chat["entry"][0]["changes"][0]["value"]["metadata"][
                "phone_number_id"
            ]
            sender_number = chat["entry"][0]["changes"][0]["value"]["metadata"][
                "display_phone_number"
            ]
            message_type = "text"  # if the message will be normal(values expected text,document,image,video, audio)
            message_body = ""  # the actual message that will be sent to usera
            button_params = None
            interactive_payload = None
            body_params = None
            message_header = None
            recipient_number = sender
            send_type = "MESSAGE"
            language = "en"
            audio = False

            # handle what message we have got
            if chat_is["type"] == "text":
                message = chat_is["text"]["body"]
            elif chat_is["type"] == "audio":
                # message = handle_audio(chat_is['audio']['id'])
                message = chat_is['audio']['id']
                audio = True
            elif chat_is["type"].lower() == "document":
                message = "document uploaded"
            elif chat_is["type"].lower() == "image":
                message = "image uploaded"
            elif chat_is["type"].lower() == "location":
                # message = chat_is['location']
                message = "location"
                payload = "location"
            elif chat_is["type"].lower() == "button":
                message = chat_is["button"]["text"]
                payload = chat_is["button"]["payload"]
            elif chat_is["type"] == "interactive":
                if chat_is["interactive"]["type"] == "list_reply":
                    message = chat_is["interactive"]["list_reply"]["title"]
                    payload = chat_is["interactive"]["list_reply"]["id"]
                elif chat_is["interactive"]["type"] == "button_reply":
                    message = chat_is["interactive"]["button_reply"]["title"]
                    payload = chat_is["interactive"]["button_reply"]["id"]
                else:
                    message = (
                        json.loads(chat_is["interactive"]["nfm_reply"]["response_json"])
                        if isinstance(
                            chat_is["interactive"]["nfm_reply"]["response_json"], str
                        )
                        else chat_is["interactive"]["nfm_reply"]["response_json"]
                    )
                    
                    message = json.dumps(message)

            else:
                ch.basic_ack(delivery_tag=method.delivery_tag)
                return

            user_master_instance = db.query(MasterData).filter(
                MasterData.number == recipient_number
            )  # here user information is store which are asked when user first comes to the bot like name,passport number
            user_master_data = user_master_instance.first()

            user_state_instance = (
                db.query(BLSData)
                .filter(BLSData.number == recipient_number)
                .filter(BLSData.status.in_(["START", "ONGOING"]))
            )  # this is the main table that maintain state step and everything
            user_state_data = user_state_instance.first()

            if user_master_data:
                if user_state_data:
                    if isinstance(message, str) and "abort" in message.lower():
                        user_state_instance.update({"status": "ABORTED"})
                        message_body = """
✨ Your session has been completed successfully!

😊 You can start a new session anytime and continue availing our services seamlessly.

🌍 Thank you for choosing BLS International!
"""
                    else:
                        gemini_response = process_message(
                            message,
                            user_state_data.step,
                            user_state_data.user_data,
                            user_state_data.service,
                            jsonable_encoder(user_master_data),audio
                        )
                        print("\nGroq Response:", gemini_response, "\n")
                        if user_state_data.status == "START":
                            if user_state_data.step == "account_setup":

                                if gemini_response["is_verify"]:

                                    message_body = """
🌍 *Welcome to BLS International Services*

Your trusted partner for visa, travel & consular assistance ✨

🌐 *MAIN MENU* 🌐

🔹 🛂 *Visa Services*
Visa applications, appointments & status tracking

🔹 📘 *Passport & Consular*
Passport renewal, OCI, PCC & consular services

🔹 ✍️ *Attestation Services*
Document legalization & attestation support

🔹 ✈️ *Flight Tickets*
Domestic & international flight bookings

🔹 🏨 *Hotel Booking*
Easy hotel reservations for your journey

🔹 🛡️ *Travel Insurance*
Travel protection plans & assistance

🔹 💱 *Forex & SIM Cards*
Forex exchange & international SIM services

🔹 ⭐ *Additional Services*
Premium lounge, courier, SMS & more

🔹 📂 *My Applications*
Track your applications & requests

🔹 🆘 *Help & Support*
FAQs, customer support & assistance

💬 *You can type the service name/number or simply select an option below anytime.*
"""
                                    message_type = "interactive"
                                    interactive_payload = [
                                        {
                                            "type": "flow",
                                            "flow_token": f"{recipient_number[2:]}",
                                            "flow_id": "2235151260353251",
                                            "flow_button": "Open",
                                            "flow_payload": "navigate",
                                        }
                                    ]
                                    user_master_instance.update(
                                        gemini_response["user_data"]
                                    )
                                    user_state_instance.update(
                                        {
                                            "user_data": {
                                                **user_state_data.user_data,
                                                **gemini_response["user_data"],
                                            },
                                            "step": "choose_service",
                                            "service": "main",
                                        }
                                    )

                                else:
                                    message_body = gemini_response["question"]
                                    if gemini_response["user_data"] != {}:
                                        user_master_instance.update(
                                            gemini_response["user_data"]
                                        )
                                        user_state_instance.update(
                                            {
                                                "user_data": {
                                                    **user_state_data.user_data,
                                                    **gemini_response["user_data"],
                                                }
                                            }
                                        )
                            elif user_state_data.step == "choose_service":
                                message_body = gemini_response["question"]
                                if 'options' in gemini_response and len(gemini_response['options']) > 0:
                                    message_type = "interactive"
                                    if len(gemini_response['options']) > 3:
                                        message_header = "Choose"
                                        interactive_payload = [
                                            {
                                                "type":"list",
                                                "header":"Choose",
                                                "options":[
                                                {
                                                    "id":option,
                                                    "title":option[:24]
                                                } for option in gemini_response['options']
                                            ]
                                            }
                                        ]
                                    else:
                                        interactive_payload = [{
                                            "type":"button",
                                            "options":[
                                                {
                                                    "id":option,
                                                    "title":option[:20]
                                                } for option in gemini_response['options']
                                            ]
                                        }]
                                if gemini_response["is_verify"]:
                                    
                                    user_state_instance.update(
                                        {
                                            "user_data": {
                                                **user_state_data.user_data,
                                                **gemini_response["user_data"],
                                            },
                                            "step": gemini_response["next_step"],
                                            "service": gemini_response["service"],
                                            "status": "ONGOING",
                                        }
                                    )


                            elif user_state_data.step == "main":
                                if gemini_response["is_verify"]:
                                    if gemini_response['next_step'] == "about" or "about" in message.lower():
                                        message_type = "interactive"
                                        interactive_payload = [{
                                        "type":"button",
                                        "options":[
                                                {
                                                    "id":"main",
                                                    "title":"Main Menu"
                                                }
                                            ]
                                        }]
                                        message_body = """
🌍 *About BLS International*

BLS International is a trusted global partner for visa, passport, consular, and travel-related services, serving customers across 70+ countries worldwide.

We provide seamless assistance for:

🛂 Visa & Passport Services
✈️ Flight & Hotel Bookings
🛡️ Travel Insurance & Forex
📱 International SIM Cards
⭐ Premium Travel Assistance Services

Our mission is to make your travel and documentation journey smooth, secure, and hassle-free with reliable customer support and global expertise.

Ready to get started with BLS services? 👇                    
"""
                                        user_state_instance.update({"status":"COMPLETE"})
                                    elif gemini_response['next_step'] == "choose_service":
                                        # service selection flow
                                        ##changes
                                        message_type = "interactive"
                                        message_body = """
🌍 *Welcome to BLS International Services*

Your trusted partner for visa, travel & consular assistance ✨

🌐 *MAIN MENU* 🌐

🔹 🛂 *Visa Services*
Visa applications, appointments & status tracking

🔹 📘 *Passport & Consular*
Passport renewal, OCI, PCC & consular services

🔹 ✍️ *Attestation Services*
Document legalization & attestation support

🔹 ✈️ *Flight Tickets*
Domestic & international flight bookings

🔹 🏨 *Hotel Booking*
Easy hotel reservations for your journey

🔹 🛡️ *Travel Insurance*
Travel protection plans & assistance

🔹 💱 *Forex & SIM Cards*
Forex exchange & international SIM services

🔹 ⭐ *Additional Services*
Premium lounge, courier, SMS & more

🔹 📂 *My Applications*
Track your applications & requests

🔹 🆘 *Help & Support*
FAQs, customer support & assistance

💬 *You can type the service name/number or simply select an option below anytime.*
"""
                                        
                                        interactive_payload = [
                                            {
                                                "type": "flow",
                                                "flow_token": f"{recipient_number[2:]}",
                                                "flow_id": "2235151260353251",
                                                "flow_button": "Open",
                                                "flow_payload": "navigate",
                                            }
                                        ]
                                        user_state_instance.update({"step":"choose_service"})
                                    else:
                                        message_body = gemini_response["question"]
                                else:
                                    if 'options' in gemini_response and len(gemini_response['options']) > 0:
                                        message_type = "interactive"
                                        if len(gemini_response['options']) > 3:
                                            message_header = "Choose"
                                            interactive_payload = [
                                                {
                                                    "type":"list",
                                                    "header":"Choose",
                                                    "options":[
                                                    {
                                                        "id":option,
                                                        "title":option[:24]
                                                    } for option in gemini_response['options']
                                                ]
                                                }
                                            ]
                                        else:
                                            interactive_payload = [{
                                                "type":"button",
                                                "options":[
                                                    {
                                                        "id":option,
                                                        "title":option[:20]
                                                    } for option in gemini_response['options']
                                                ]
                                            }]
                                    message_body = gemini_response["question"]
                        
                        elif user_state_data.status == "ONGOING":
                            message_body = gemini_response["question"]
                            print('here it is\n\n')
                            if 'options' in gemini_response and len(gemini_response['options']) > 0:
                                message_type = "interactive"
                                if len(gemini_response['options']) > 3:
                                    message_header = "Choose"
                                    interactive_payload = [
                                        {
                                            "type":"list",
                                            "header":"Choose",
                                            "options":[
                                            {
                                                "id":option,
                                                "title":option[:24]
                                            } for option in gemini_response['options']
                                        ]
                                        }
                                    ]
                                else:
                                    interactive_payload = [{
                                        "type":"button",
                                        "options":[
                                            {
                                                "id":option,
                                                "title":option[:20]
                                            } for option in gemini_response['options']
                                        ]
                                    }]

                            if gemini_response["is_verify"]:
                                if gemini_response["is_complete"]:
                                    status = "COMPLETE"
                                else:
                                    status = "ONGOING"
                                    message_body = f'{message_body}\n> Type "Abort" to end your session'
                                user_state_instance.update(
                                    {
                                        "user_data": {
                                            **user_state_data.user_data,
                                            **gemini_response["user_data"],
                                            "previous_question": gemini_response[
                                                "question"
                                            ],
                                        },
                                        "status": status,
                                        "step": gemini_response["next_step"],
                                        "service": gemini_response["service"],
                                    }
                                )
                            
                            else:
                                user_state_instance.update(
                                    {
                                        "user_data": {
                                            **user_state_data.user_data,
                                            **gemini_response["user_data"],
                                        }
                                    }
                                )
                else:
                    
                    if isinstance(message,str) and payload is None:
                        message_body = """
🌟 *Welcome to BLS International!*

Your trusted partner for:

🛂 Visa & Passport Services
✈️ Flights & Hotels
🛡️ Travel Insurance & Forex
📱 International SIM Cards
⭐ Premium Travel Assistance

We’re here to make your travel journey smooth and hassle-free 🌍

Please choose an option below to continue 👇
"""
                        message_type = "interactive"
                        interactive_payload = [{
                            "header_image":"https://citylyticsmain.in:11116/assets/bls_welcome.png",
                            "type":"button",
                            "options":[
                                {
                                    "id":"about",
                                    "title":"About BLS"
                                },
                                {
                                    "id":"main",
                                    "title":"Main Menu"
                                }
                            ]
                        }]
                        db.add(
                            BLSData(
                                **{
                                    "id": ULID().hex,
                                    "number": recipient_number,
                                    "service": "main",
                                    "status": "START",
                                    "step": "main",
                                    "user_data": {},
                                }
                            )
                        )
            
                    elif isinstance(message,str) and payload == "main":
                        # main menu flow
                        ##changes
                        message_type = "interactive"
                        message_body = """
🌍 *Welcome to BLS International Services*

Your trusted partner for visa, travel & consular assistance ✨

🌐 *MAIN MENU* 🌐

🔹 🛂 *Visa Services*
Visa applications, appointments & status tracking

🔹 📘 *Passport & Consular*
Passport renewal, OCI, PCC & consular services

🔹 ✍️ *Attestation Services*
Document legalization & attestation support

🔹 ✈️ *Flight Tickets*
Domestic & international flight bookings

🔹 🏨 *Hotel Booking*
Easy hotel reservations for your journey

🔹 🛡️ *Travel Insurance*
Travel protection plans & assistance

🔹 💱 *Forex & SIM Cards*
Forex exchange & international SIM services

🔹 ⭐ *Additional Services*
Premium lounge, courier, SMS & more

🔹 📂 *My Applications*
Track your applications & requests

🔹 🆘 *Help & Support*
FAQs, customer support & assistance

💬 *You can type the service name/number or simply select an option below anytime.*
"""
                        
                        interactive_payload = [
                            {
                                "type": "flow",
                                "flow_token": f"{recipient_number[2:]}",
                                "flow_id": "2235151260353251",
                                "flow_button": "Open",
                                "flow_payload": "navigate",
                            }
                        ]
                        
                        db.add(
                            BLSData(
                                **{
                                    "id": ULID().hex,
                                    "number": recipient_number,
                                    "service": "main",
                                    "status": "START",
                                    "step": "choose_service",
                                    "user_data": {},
                                }
                            )
                        )
                        
            else:
                if isinstance(message,str) and "about" in message.lower() and user_state_data:
                    message_type = "interactive"
                    interactive_payload = [{
                        "type":"button",
                        "options":[
                            {
                                "id":"register",
                                "title":"Register"
                            }
                        ]
                    }]
                    message_body = """
🌍 *About BLS International*

BLS International is a trusted global partner for visa, passport, consular, and travel-related services, serving customers across 70+ countries worldwide.

We provide seamless assistance for:

🛂 Visa & Passport Services
✈️ Flight & Hotel Bookings
🛡️ Travel Insurance & Forex
📱 International SIM Cards
⭐ Premium Travel Assistance Services

Our mission is to make your travel and documentation journey smooth, secure, and hassle-free with reliable customer support and global expertise.

Ready to get started with BLS services? 👇                    
"""
                    user_state_instance.update({"status":"COMPLETE"})
                    
                elif isinstance(message,str) and "register" in message.lower() and user_state_data:
                    ...
                    # register flow
                    ##changes
                    message_type = "interactive"
                    message_body = """
📝 *Let’s Get You Started with BLS International!*

We’ll need a few basic details to create your BLS profile:

👤 Full Name
🛂 Passport Number
🌍 Nationality
🎂 Date of Birth
📧 Email Address

You can share the details through:

⌨️ Text Message
🎤 Voice Message
📋 Or simply fill out the registration form

Click the *Register* button below to continue 👇
"""
                    
                    interactive_payload = [
                        {
                            "type": "flow",
                            "flow_token": f"{recipient_number[2:]}",
                            "flow_id": "1299251968330822",
                            "flow_button": "Register",
                            "flow_payload": "navigate",
                        }
                    ]
                    db.add(MasterData(
                        **{
                            "id":ULID().hex,
                            "number":recipient_number
                        }
                    ))
                    user_state_instance.update({"service":"registration","step":"account_setup"})
                else:
                    if isinstance(message,str) and payload is None:
                        message_type = "interactive"
                        interactive_payload = [{
                            "header_image":"https://citylyticsmain.in:11116/assets/bls_welcome.png",
                            "type":"button",
                            "options":[
                                {
                                    "id":"about",
                                    "title":"About BLS"
                                },
                                {
                                    "id":"register",
                                    "title":"Register"
                                }
                            ]
                        }]
                        message_body = """
🌟 *Welcome to BLS International!*

Your trusted partner for:

🛂 Visa & Passport Services
✈️ Flights & Hotels
🛡️ Travel Insurance & Forex
📱 International SIM Cards
⭐ Premium Travel Assistance

We’re here to make your travel journey smooth and hassle-free 🌍

Please choose an option below to continue 👇
"""
                        db.add(
                            BLSData(
                                **{
                                    "id": ULID().hex,
                                    "number": recipient_number,
                                    "service": "welcome",
                                    "status": "START",
                                    "step": "welcome",
                                    "user_data": {},
                                }
                            )
                        )

                    else:
                        # register flow message ##changes
                        message_type = "interactive"
                        message_body = """
📝 *Let’s Get You Started with BLS International!*

We’ll need a few basic details to create your BLS profile:

👤 Full Name
🛂 Passport Number
🌍 Nationality
🎂 Date of Birth
📧 Email Address

You can share the details through:

⌨️ Text Message
🎤 Voice Message
📋 Or simply fill out the registration form

Click the *Register* button below to continue 👇
"""
                        
                        interactive_payload = [
                            {
                                "type": "flow",
                                "flow_token": f"{recipient_number[2:]}",
                                "flow_id": "1299251968330822",
                                "flow_button": "Register",
                                "flow_payload": "navigate",
                            }
                        ]
                        
                        db.add(MasterData(
                            **{
                                "id":ULID().hex,
                                "number":recipient_number
                            }
                        ))
                        db.add(
                            BLSData(
                                **{
                                    "id": ULID().hex,
                                    "number": recipient_number,
                                    "service": "registration",
                                    "status": "START",
                                    "step": "account_setup",
                                    "user_data": {},
                                }
                            )
                        )

            res = send_message(
                message_type,
                message_body,
                button_params,
                interactive_payload,
                body_params,
                message_header,
                recipient_number,
                send_type,
                language,
                sender_number,
            )
            ch.basic_ack(delivery_tag=method.delivery_tag)
            print("here sent")
            return

        except:
            traceback.print_exc()
            ch.basic_ack(delivery_tag=method.delivery_tag)
            return ()

        finally:
            db.commit()
            db.close()
