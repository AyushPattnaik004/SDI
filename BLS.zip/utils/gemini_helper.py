service_step_decription = {
    "registration": {
        "account_setup": {
            "decription": "In this step we ask user about their basic details such as full name,passport number,date of birth,email address",
            "valid_answer": "The valid answer for this step will be all the details that are asked to user",
            "next_step": {
                "step": "choose_service",
                "question": "The question should contain the services that are currently available with us. The question should be good look wise.",
                "description": "In this step we ask user to choose a service from our service list i.e appointment booking,flight booking,additional services",
            },
        }
    },
    "main": {
        "main": {
            "description": "",
            "valid_answer": "",
            "next_step": [
                {
                    "step": "about",
                    "question": "About bls international",
                    "description": "If the user message context is to know about bls international or the user message is about us.",
                },
                {
                    "step": "choose_service",
                    "question": "The question should contain the main services that are available with us",
                    "description": "In this step we ask user to choose a service from our service list i.e appointment booking,flight booking,additional services",
                },
            ],
        },
        "choose_service": {
            "desription": "In this step we ask user to choose a service from our service list i.e appointment booking,flight booking,additional services",
            "valid_answer": "The valid answer should be one service from our service list i.e appointment booking,flight booking,additional services",
            "next_step": [
                {
                    "step": "additional_service_menu",
                    "question": "The question should contain the additional services that are available with us such as SIM CARD SERVICE,PHOTO BOOTH,PRIME TIME APPOINTMENT,FORM FILLING,SMS SERVICE,PREMIUM LOUNGE,COURIER",
                    "description": "In this step we will ask the user the additional services that are available with us",
                },
                {
                    "step": "choose_country",
                    "question": "Which country are you applying visa for?",
                    "description": "Visa service country selection",
                },
                {
                    "step": "passport_choose_service",
                    "question": "Please select a passport or consular service. Provide the list of services like Passport Renewal, New Passport Application , OCI (Overseas Citizen of India) Card ,Police Clearance Certificate (PCC) ,Emergency Travel Document , Life Certificate (Jeevan Pramaan), Consular Attestation",
                    "description": "Passport & Consular service menu",
                },
                {
                    "step": "attestation_type",
                    "question": "Please select document attestation type and provide document types as educational,apostille,commercial,personal",
                    "description": "Attestation service type selection",
                },
                {
                    "step": "flight_booking",
                    "question": "Please share your travel details for flight booking",
                    "description": "International flight booking workflow",
                },
                {
                    "step": "hotel_booking",
                    "question": "Please share your hotel booking requirements",
                    "description": "Hotel booking workflow",
                },
                {
                    "step": "travel_booking",
                    "question": "Please share your travel insurance requirements",
                    "description": "Travel insurance workflow",
                },
                {
                    "step": "forex_booking",
                    "question": "Please share your forex requirements",
                    "description": "Forex and SIM card workflow",
                },
                {
                    "step": "help_support",
                    "question": "How can we assist you today?",
                    "description": "Help and support workflow",
                },
            ],
        },
    },
    "additional_service": {
        "additional_service_menu": {
            "description": "In this step we have asked the user the additional services that are available with us",
            "valid_answer": "Courier,Photo copy - Black and White,SMS,Call back service(STS),Premium Lounge,Printing,Form Filling,Flexi hours – Passport collection,Door Step Services,Prime Time Appointment,Photo booth,Sim Card Service,Logistic Charges (For Nepal & Colombo),Courier Assurance,Doctor on call,BLS Service Charges",
            "next_step": [
                {
                    "step": "courier_start",
                    "question": "Ask user for full name to start Courier Service request",
                    "description": "Courier service workflow start",
                },
                {
                    "step": "photo_copy_black_and_white_start",
                    "question": "Ask user for full name to start Photo copy service",
                    "description": "Photo copy service workflow start",
                },
                {
                    "step": "sms_start",
                    "question": "Ask user for full name to activate SMS Service",
                    "description": "SMS service workflow start",
                },
                {
                    "step": "call_back_service_start",
                    "question": "Ask user for full name to schedule callback service",
                    "description": "Call back service workflow start",
                },
                {
                    "step": "premium_lounge_start",
                    "question": "Ask user for full name to start Premium Lounge service. If we already have the information then we can confirm from the user",
                    "description": "Premium Lounge workflow start. Start with full name if not available already.",
                },
                {
                    "step": "printing_start",
                    "question": "Ask user for full name to start Printing service",
                    "description": "Printing service workflow start",
                },
                {
                    "step": "form_filling_start",
                    "question": "Ask user for full name to start Form Filling assistance",
                    "description": "Form filling workflow start",
                },
                {
                    "step": "flexi_hours_passport_collection_start",
                    "question": "Ask user for full name to start Flexi Hours Passport Collection",
                    "description": "Flexi Hours Passport Collection workflow start",
                },
                {
                    "step": "door_step_services_start",
                    "question": "Ask user for full name to start Door Step Service",
                    "description": "Door Step Services workflow start",
                },
                {
                    "step": "prime_time_appointment_start",
                    "question": "Ask user for full name to start Prime Time Appointment",
                    "description": "Prime Time Appointment workflow start",
                },
                {
                    "step": "photo_booth_start",
                    "question": "Ask user for full name to start Photo Booth service",
                    "description": "Photo Booth workflow start",
                },
                {
                    "step": "sim_card_service_start",
                    "question": "Ask user for full name to start SIM Card Service",
                    "description": "SIM Card Service workflow start",
                },
                {
                    "step": "logistic_charges_start",
                    "question": "Ask user for full name to start Logistic Charges service",
                    "description": "Logistic Charges workflow start",
                },
                {
                    "step": "courier_assurance_start",
                    "question": "Ask user for full name to start Courier Assurance service",
                    "description": "Courier Assurance workflow start",
                },
                {
                    "step": "doctor_on_call_start",
                    "question": "Ask user for full name to start Doctor On Call service",
                    "description": "Doctor On Call workflow start",
                },
                {
                    "step": "bls_service_charges_start",
                    "question": "Ask user for full name to know BLS Service Charges",
                    "description": "BLS Service Charges workflow start",
                },
            ],
        },
        # =========================================================
        # COURIER
        # =========================================================
        "courier_start": {
            "description": "In this step we ask user full name for courier service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "courier_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number",
            },
        },
        "courier_passport_number": {
            "description": "Ask passport number for courier service",
            "valid_answer": "Any Passport number",
            "next_step": {
                "step": "courier_delivery_address",
                "question": "Please share your delivery address.",
                "description": "Ask delivery address",
            },
        },
        "courier_delivery_address": {
            "description": "Ask delivery address",
            "valid_answer": "Valid delivery address",
            "next_step": {
                "step": "courier_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number",
            },
        },
        "courier_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "courier_completed",
                "question": "Your Courier Service request has been submitted successfully.",
                "description": "Courier service completed",
            },
        },
        # =========================================================
        # PREMIUM LOUNGE
        # =========================================================
        "premium_lounge_start": {
            "description": "Ask full name for Premium Lounge service if not available else confirm if available already.",
            "valid_answer": "Full name of the user",
            "possible_next_step": [
                {
                    "step": "premium_lounge_passport_number",
                    "question": "Please share your passport number.",
                    "description": "Ask passport number if not already available",
                },
                {
                    "step": "premium_lounge_appointment_date",
                    "question": "If the name and passport number is already available then ask to share the appointment date. Provide some dates in the question.",
                    "description": "Ask appointment date directly if name and passport available",
                },
            ],
        },
        "premium_lounge_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Any Passport number",
            "next_step": {
                "step": "premium_lounge_appointment_date",
                "question": "Please share your appointment date. Add some dates in the question.",
                "description": "Ask appointment date",
            },
        },
        "premium_lounge_appointment_date": {
            "description": "Ask appointment time",
            "valid_answer": "Valid appointment time",
            "next_step": {
                "step": "premium_lounge_appointment_time",
                "question": "Please share your appointment time. Add some times in the question.",
                "description": "Ask appointment time",
            },
        },
        "premium_lounge_appointment_time": {
            "description": "Ask appointment date",
            "valid_answer": "Valid appointment date",
            "next_step": {
                "step": "premium_lounge_center_name",
                "question": "Please share your visa application centre name. Add center names like delhi,mumbai",
                "description": "Ask visa centre",
            },
        },
        "premium_lounge_center_name": {
            "description": "Ask centre name",
            "valid_answer": "Valid centre name",
            "next_step": {
                "step": "premium_lounge_completed",
                "question": "Your Premium Lounge request has been submitted successfully. And add some emojis and summary type message",
                "description": "Premium Lounge completed",
            },
        },
        # =========================================================
        # SMS SERVICE
        # =========================================================
        "sms_start": {
            "description": "Ask full name for SMS service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "sms_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number",
            },
        },
        "sms_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Any Passport number",
            "next_step": {
                "step": "sms_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number",
            },
        },
        "sms_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "sms_completed",
                "question": "SMS Service has been activated successfully.",
                "description": "SMS service completed",
            },
        },
        # =========================================================
        # FORM FILLING
        # =========================================================
        "form_filling_start": {
            "description": "Ask full name for form filling service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "form_filling_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number",
            },
        },
        "form_filling_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Any Passport number",
            "next_step": {
                "step": "form_filling_visa_type",
                "question": "Which visa category are you applying for?",
                "description": "Ask visa type",
            },
        },
        "form_filling_visa_type": {
            "description": "Ask visa type",
            "valid_answer": "Valid visa type",
            "next_step": {
                "step": "form_filling_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number",
            },
        },
        "form_filling_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "form_filling_completed",
                "question": "Your Form Filling Assistance request has been submitted successfully.",
                "description": "Form filling completed",
            },
        },
        # =========================================================
        # PRIME TIME APPOINTMENT
        # =========================================================
        "prime_time_appointment_start": {
            "description": "Ask full name for Prime Time Appointment",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "prime_time_appointment_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number",
            },
        },
        "prime_time_appointment_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Any Passport number",
            "next_step": {
                "step": "prime_time_appointment_preferred_date",
                "question": "Please share your preferred appointment date.",
                "description": "Ask preferred date",
            },
        },
        "prime_time_appointment_preferred_date": {
            "description": "Ask preferred date",
            "valid_answer": "Valid preferred date",
            "next_step": {
                "step": "prime_time_appointment_completed",
                "question": "Your Prime Time Appointment request has been submitted successfully.",
                "description": "Prime Time Appointment completed",
            },
        },
        # =========================================================
        # PHOTO BOOTH
        # =========================================================
        "photo_booth_start": {
            "description": "Ask full name for Photo Booth service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "photo_booth_number_of_photos",
                "question": "How many photographs do you need?",
                "description": "Ask number of photographs",
            },
        },
        "photo_booth_number_of_photos": {
            "description": "Ask number of photos",
            "valid_answer": "Valid number of photographs",
            "next_step": {
                "step": "photo_booth_completed",
                "question": "Your Photo Booth request has been submitted successfully.",
                "description": "Photo Booth completed",
            },
        },
        # =========================================================
        # SIM CARD SERVICE
        # =========================================================
        "sim_card_service_start": {
            "description": "Ask full name for SIM Card service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "sim_card_service_destination_country",
                "question": "Which country are you travelling to?",
                "description": "Ask destination country",
            },
        },
        "sim_card_service_destination_country": {
            "description": "Ask destination country",
            "valid_answer": "Valid destination country",
            "next_step": {
                "step": "sim_card_service_travel_date",
                "question": "Please share your travel date.",
                "description": "Ask travel date",
            },
        },
        "sim_card_service_travel_date": {
            "description": "Ask travel date",
            "valid_answer": "Valid travel date",
            "next_step": {
                "step": "sim_card_service_completed",
                "question": "Your SIM Card Service request has been submitted successfully.",
                "description": "SIM Card Service completed",
            },
        },
    },
    # =========================================================
    # VISA SERVICES
    # =========================================================
    "visa_service": {
        "choose_country": {
            "description": "Ask user to choose visa destination country",
            "valid_answer": "Any country",
            "next_step": {
                "step": "visa_summary",
                "question": "Please select visa category. Show the user some category list tourist, business, student, medical, transit, family, longstay",
                "description": "Visa category selection",
            },
        },
        "visa_summary": {
            "description": "Display visa checklist and ask user to continue appointment booking",
            "valid_answer": "tourist, business, student, medical, transit, family, longstay",
            "next_step": {
                "step": "choose_date",
                "question": "Please select appointment date. Give the user available date list",
                "description": "Appointment date selection",
            },
        },
        "choose_date": {
            "description": "Validate and confirm appointment date",
            "valid_answer": "Valid selected date",
            "next_step": {
                "step": "document_submission",
                "question": "Upload required documents",
                "description": "Document submission workflow",
            },
        },
        "document_submission": {
            "description": "Ask user to upload visa documents such as Passport Copy,Bank Statement",
            "valid_answer": "Uploaded documents",
            "next_step": {
                "step": "bank_statement_submission",
                "question": "Please upload bank statement",
                "description": "Bank statement upload",
            },
        },
        "bank_statement_submission": {
            "description": "Bank statement submission options",
            "valid_answer": "Send_Bank_Statement, Sample_Document_Format, Need_Help",
            "next_step": {
                "step": "visa_fee_summary",
                "question": "Please find the fee summary of your application ```some dummy numbers``` with oprion to select payment gateway like UPI,Credit Card,Net banking",
                "description": "The fees of the visa application that user needs to pay with payment gateway options",
            },
        },
        "visa_fee_summary": {
            "description": "Show visa fee and payment methods",
            "valid_answer": "UPI_GPay_PhonePe, Net_Banking, Debit_Credit_Card, Pay_Later",
            "next_step": {
                "step": "visa_booking_completed",
                "question": "Visa application complete with summary of visa application",
                "description": "Visa booking completed",
            },
        },
        "visa_booking_completed": {
            "description": "The visa service is completed successfully",
            "valid_answer": "Visa appointment booking completed. Share a dummy ID and summary of the booking",
            "next_step": {
                "step": "visa_completed",
                "question": "Visa application submitted successfully",
                "description": "Visa booking completed",
            },
        },
    },
    # =========================================================
    # PASSPORT & CONSULAR
    # =========================================================
    "passport_consular_service": {
        "passport_choose_service": {
            "description": "Passport and consular service menu",
            "valid_answer": "passport_renewal,new_passport_application,oci_card,pcc,emergency_travel_document,life_certificate,consular_attestation",
            "next_step": {
                "step": "apply_passport",
                "question": "Ask the user whether they want to apply now or apply later?",
                "description": "Passport workflow for applying now or later",
            },
        },
        "apply_passport": {
            "description": "Ask user to apply now or later",
            "valid_answer": "apply_now, apply_later",
            "next_step": {
                "step": "passport_service_completed",
                "question": "Passport workflow completion message with summary of user application",
                "description": "Passport workflow completed",
            },
        },
    },
    # =========================================================
    # FLIGHT BOOKING
    # =========================================================
    "flight_booking": {
        "flight_booking": {
            "description": "Collect international flight booking details",
            "valid_answer": "Origin city,destination city,departure date,return date,passengers",
            "next_step": {
                "step": "flight_selected_name",
                "question": "Please select your preferred flight and add some flight options for user to select",
                "description": "Flight selection",
            },
        },
        "flight_selected_name": {
            "description": "Ask user to select flight option.",
            "valid_answer": "Valid flight name",
            "next_step": {
                "step": "flight_last_step",
                "question": "Proceed with booking or bundle",
                "description": "Final flight confirmation",
            },
        },
        "flight_last_step": {
            "description": "Final flight booking step",
            "valid_answer": "book,add_bundle,save_book_later",
            "next_step": {
                "step": "flight_booking_completed",
                "question": "Flight booking completed",
                "description": "Flight booking completed",
            },
        },
    },
    # =========================================================
    # HOTEL BOOKING
    # =========================================================
    "hotel_booking": {
        "hotel_booking": {
            "description": "Collect hotel booking requirements",
            "valid_answer": "Destination,checkin,checkout,guests,rooms,hotel_category",
            "next_step": {
                "step": "hotel_selected_name",
                "question": "Please select your hotel",
                "description": "Hotel selection",
            },
        },
        "hotel_selected_name": {
            "description": "Hotel selection confirmation",
            "valid_answer": "Valid hotel name",
            "next_step": {
                "step": "hotel_booking_completed",
                "question": "Hotel booking completed",
                "description": "Hotel booking completed",
            },
        },
    },
    # =========================================================
    # TRAVEL INSURANCE
    # =========================================================
    "travel_insurance": {
        "travel_booking": {
            "description": "Collect travel insurance details",
            "valid_answer": "destination,start date,end date,travellers,budget,trip type",
            "next_step": {
                "step": "travel_booking_recommendation",
                "question": "Choose insurance plan",
                "description": "Insurance recommendation",
            },
        },
        "travel_booking_recommendation": {
            "description": "Travel insurance plan recommendation",
            "valid_answer": "basic_plan,standard_plan,premium_plan",
            "next_step": {
                "step": "last_step_travel_insurance",
                "question": "Confirm insurance booking",
                "description": "Insurance confirmation",
            },
        },
        "last_step_travel_insurance": {
            "description": "Travel insurance final confirmation",
            "valid_answer": "confirm",
            "next_step": {
                "step": "travel_insurance_completed",
                "question": "Travel insurance booked successfully",
                "description": "Travel insurance completed",
            },
        },
    },
    # =========================================================
    # FOREX & SIM CARD
    # =========================================================
    "forex_service": {
        "forex_booking": {
            "description": "Collect forex booking requirements",
            "valid_answer": "destination country,travel date,forex amount,currency",
            "next_step": {
                "step": "forex_sim_card",
                "question": "Do you also need international SIM card?",
                "description": "SIM card upsell",
            },
        },
        "forex_sim_card": {
            "description": "Ask user if SIM card is required",
            "valid_answer": "yes,no",
            "possible_next_step": [
                {
                    "step": "forex_sim_card_options",
                    "question": "Choose SIM card plan",
                    "description": "SIM card selection",
                },
                {
                    "step": "forex_booking_completed",
                    "question": "Forex booking completed",
                    "description": "Forex completed without SIM",
                },
            ],
        },
        "forex_sim_card_options": {
            "description": "SIM card package selection",
            "valid_answer": "order_data_sim,get_global_esim",
            "next_step": {
                "step": "forex_booking_completed",
                "question": "Forex and SIM request completed",
                "description": "Forex completed",
            },
        },
    },
    # =========================================================
    # ATTESTATION
    # =========================================================
    "attestation_service": {
        "attestation_type": {
            "description": "Select attestation document category",
            "valid_answer": "educational,apostille,commercial,personal",
            "next_step": {
                "step": "attestation_country_check",
                "question": "Please share destination country and provide some examples",
                "description": "Destination country for attestation",
            },
        },
        "attestation_country_check": {
            "description": "Show attestation details and pricing",
            "valid_answer": "Valid country name",
            "next_step": {
                "step": "attestation_fee",
                "question": "provide a fee breakup with document type and the country entered and ask the user whether to proceed",
                "description": "Attestation Fee",
            },
        },
        "attestation_fee": {
            "description": "Fee breakup and user cofirmation",
            "valid_answer": "proceed",
            "next_step": {
                "step": "attestation_next_action",
                "question": "Schedule pickup or pay and proceed",
                "description": "Attestation next action",
            },
        },
        "attestation_next_action": {
            "description": "Attestation completion step",
            "valid_answer": "Schedule_Pickup,pay_proceed",
            "next_step": [
                {
                    "step": "attestation_address",
                    "question": "Please provide address for pickup",
                    "description": "If the user have selected schedule pickup then ask for address",
                },
                {
                    "step": "attestation_pay",
                    "question": "Please choose your preffered payment option like UPI,Credit Card, Net Banking",
                    "description": "If the user have selected pay and proceed  then ask for preffered payment options.",
                },
            ],
        },
        "attestation_address": {
            "description": "If the user asks for schedule pickup then we have to collect address from user.",
            "valid_answer": "Address",
            "next_step": {
                "step": "attestation_process_completed",
                "question": "Attestation request completed",
                "description": "Attestation completed",
            },
        },
        "attestation_pay": {
            "description": "Ask the user for prefered payment gateway like UPI, Credit Card ot Net Banking",
            "valid_answer": "UPI or Credit Card or Net Banking",
            "next_step": {
                "step": "attestation_process_completed",
                "question": "Attestation request completed",
                "description": "Attestation completed",
            },
        },
    },
    # =========================================================
    # HELP & SUPPORT
    # =========================================================
    "help_support": {
        "help_support": {
            "description": "User support and FAQ handling",
            "valid_answer": "User support query",
            "next_step": {
                "step": "help_support",
                "question": "Please share your query",
                "description": "Continue support conversation",
            },
        }
    },
}

service_informations = {
    "registration": "When a user first visits our chatbot, we collect the user's basic profile details such as full name, passport number, nationality, email address, and date of birth to create their BLS account and personalize future services.",
    "main": "This is the primary service selection step and about section where users choose the service they want to continue with. Available services include Visa Services, Passport & Consular Services, Attestation Services, Flight Booking, Hotel Booking, Travel Insurance, Forex & SIM Card Services, Help & Support, and Additional Services.Or user know about bls internation",
    "additional_service": "This section includes all additional value-added services available with BLS such as Courier, Photo Copy - Black and White, SMS Service, Call Back Service (STS), Premium Lounge, Printing, Form Filling Assistance, Flexi Hours Passport Collection, Door Step Services, Prime Time Appointment, Photo Booth, SIM Card Service, Logistic Charges (For Nepal & Colombo), Courier Assurance, Doctor on Call, and BLS Service Charges.",
    "visa_service": "This service helps users with visa application workflows including country selection, visa category selection, appointment booking, document submission, fee payment, and visa application completion. The system also supports visa checklist guidance and appointment scheduling.",
    "passport_consular_service": "This service handles Passport Renewal, New Passport Applications, OCI Card services, PCC (Police Clearance Certificate), Emergency Travel Documents, Life Certificate (Jeevan Pramaan), and Consular Attestation related workflows.",
    "flight_booking": "This service helps users search and book international flight tickets by collecting origin city, destination city, departure date, return date, and passenger details. Users can compare flight options, choose flights, and complete booking workflows.",
    "hotel_booking": "This service helps users find and book hotels based on destination, check-in/check-out dates, number of guests, rooms, and hotel category preferences such as 3-star, 4-star, or 5-star hotels.",
    "travel_insurance": "This service helps users select and purchase international travel insurance plans based on destination, travel dates, number of travelers, trip type, and budget preference. The workflow includes plan recommendations such as Basic, Standard, and Premium coverage.",
    "forex_service": "This service helps users with foreign exchange requests, forex card assistance, currency exchange estimation, and international SIM/eSIM services for overseas travel.",
    "attestation_service": "This service supports document attestation workflows including Educational Certificate Attestation, Apostille, Commercial Document Attestation, and Personal Document Attestation along with embassy processing and pickup support.",
    "help_support": "This service provides customer support assistance for visa processing, document requirements, refund policies, nearest VAC information, helpline support, and live agent assistance. Users can also ask free-text support queries in multiple languages.",
}

SYSTEM_PROMPT = """
You are an intelligent conversational workflow assistant for BLS International.

Your responsibility is:
1. Validate user response according to current workflow step.
2. Extract user information.
3. Answer user questions naturally.
4. Continue workflow without breaking conversation.
5. Return ONLY valid JSON.
6. Never return markdown.
7. Never explain outside JSON.
8. If the question includes any options then return the list of option in `options` key else return an empty list

==================================================
VERY IMPORTANT WORKFLOW RULES
==================================================




You MUST:
- rewrite the question naturally
- make it conversational
- make it visually attractive
- add emojis
- add new lines where required
- make it short and crisp
- never return the raw instruction text

BAD EXAMPLE:
"Please share your appointment date. Add some dates in the question."

GOOD EXAMPLE:
"📅 Please select your appointment date.\n\nYou can choose dates like:\n• 12 Aug 2026\n• 14 Aug 2026\n• 18 Aug 2026"

==================================================
STEP SKIPPING RULES
==================================================

2. If required data already exists in USER DATA or ALREADY_AVAILABLE_FIELDS:
- skip that step automatically
- move to the next missing step

Example:

If full_name and passport_number already exist:
DO NOT ask again.

Move directly to:
appointment_date

==================================================
INTERRUPTION RULES
==================================================

3. If the user asks a side question:
- answer naturally
- continue the workflow
- ask the pending question again

Example:

User:
"Tell me about Premium Lounge"

Output question:
"✨ Premium Lounge offers faster and more comfortable visa processing assistance.\n\nTo continue, please share your appointment date 📅"

==================================================
QUESTION FORMAT RULES
==================================================

4. ALL questions must:
- contain emojis
- contain proper formatting
- contain line breaks where required
- be user friendly
- be concise
- look visually clean on WhatsApp

GOOD FORMAT:

"📍 Please select your visa centre.\n\nAvailable centres:\n• Delhi\n• Mumbai\n• Chennai"

==================================================
VALIDATION RULES
==================================================

5. If user gives valid answer:
- is_verify = true

6. If user gives invalid answer:
- is_verify = false
- explain politely
- ask again

7. If user partially answers:
- extract available fields
- ask remaining fields
- is_verify = false

==================================================
COMPLETION RULES
==================================================

8. If all steps are completed:
- set is_complete = true
- provide summary style response
- add emojis

Example:

"✅ Your Premium Lounge request has been submitted successfully.\n\n📋 Summary:\n• Name: Rahul Sharma\n• Centre: Delhi\n• Appointment: 12 Aug 2026"

==================================================
OUTPUT FORMAT
==================================================

Always return JSON in this exact format:

{
    "is_verify": true,
    "next_step": "step_name_or_null",
    "question": "friendly formatted chatbot response",
    "user_data": {},
    "intent": "answer|question|service_query|workflow|invalid",
    "is_complete": true,
    "options":["option1","option2",...]
    "service": "must ONLY be one of these exact values:
- registration
- main
- additional_service
- visa_service
- passport_consular_service
- flight_booking
- hotel_booking
- travel_insurance
- forex_service
- attestation_service
- help_support"

Never generate any other value.
Never infer service from workflow step names."

}


IMPORTANT:
If a field already exists in USER DATA then skip that step automatically.
Do not ask already available information again.

==================================================
STRICT RULES
==================================================

- NEVER return raw step instructions.
- ALWAYS rewrite questions conversationally.
- ALWAYS beautify responses.
- ALWAYS maintain workflow continuity.
- ALWAYS skip already collected fields.
- ALWAYS return ONLY JSON.
"""

import json
import google.generativeai as genai
from core.env import GEMINI_API_KEY
from google import genai as genai_new
from google.genai import types
import re
import requests
from datetime import datetime
from os import getcwd

AUDIO_RECEIVED_LOCATION = (f"{getcwd()}/assets/audio/received/").replace(
    "/ap_files", ""
)


genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel(model_name="gemini-2.5-flash")


def parse_gemini_json(text):

    text = text.strip()

    # Remove markdown
    text = re.sub(r"^```json", "", text)
    text = re.sub(r"^```", "", text)
    text = re.sub(r"```$", "", text)

    text = text.strip()

    # Extract JSON object
    match = re.search(r"\{.*\}", text, re.DOTALL)

    if not match:
        raise Exception("No valid JSON found")

    json_text = match.group(0)

    # ==========================================
    # FIX RAW NEWLINES INSIDE JSON STRINGS
    # ==========================================

    fixed_json = ""
    inside_string = False
    escape = False

    for char in json_text:

        if char == '"' and not escape:
            inside_string = not inside_string

        if char == "\n" and inside_string:
            fixed_json += "\\n"
        else:
            fixed_json += char

        escape = char == "\\" and not escape

    return json.loads(fixed_json)


def process_message(
    user_message, current_step, user_data, service, user_master_data, audio
):

    step_info = service_step_decription[service][current_step]

    if audio:
        user_prompt = f"""
CURRENT SERVICE:
{service}

CURRENT STEP:
{current_step}

STEP INFORMATION:
{json.dumps(step_info, indent=2)}

CURRENT USER DATA:
{json.dumps(user_data, indent=2)}

MASTER USER DATA:
{json.dumps(user_master_data, indent=2)}

USER MESSAGE:
availabe in audio file

IMPORTANT:
- Skip already available fields
- Continue workflow naturally
- Answer side questions briefly
- Return ONLY valid JSON
- All new lines inside JSON strings must use escaped \\n format.
- Never use raw line breaks inside JSON values.
"""
        print("Audio ID Received:", user_message, datetime.now())
        url = "https://backend.aisensy.com/direct-apis/t1/get-media"

        payload = {"id": user_message}
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhc3Npc3RhbnRJZCI6IjZhMDQyM2E5ZDI4YTRjMzNkMTIxOWQ2ZSIsImNsaWVudElkIjoiNjg5YjczNmEwYWJmZTYyNmRkMDQwMmQwIiwiaWF0IjoxNzc4NjU3Njk3fQ.K03wN3Tg_qBPh8YGJ8AxNwhjaWMkP7FCf8DZyUmIiv8",
        }
        response = requests.post(url, json=payload, headers=headers)
        # file_name=f"{sender}_{datetime.now()}.mp3"
        response = response.json()
        print("Audio Bytes Received (From Meta)", user_message, datetime.now())
        buffer_data = bytes(response["data"])
        # file_name = f"received_audio_{datetime.now()}.mp3"
        # final_file_location = AUDIO_RECEIVED_LOCATION + file_name
        # with open(final_file_location, "wb") as f:
        #     f.write(buffer_data)
        # print("Audio Saved:", user_message, datetime.now())

        client = genai_new.Client(api_key=GEMINI_API_KEY)
        # audio_file = client.files.upload(file=final_file_location)
        
        contents_payload = [
            SYSTEM_PROMPT,
            user_prompt,
            types.Part.from_bytes(
                data=buffer_data,
                mime_type="audio/mp3",  # Note: Ensure this matches WhatsApp incoming audio type (usually audio/ogg or audio/aac/mp4, adjust if needed)
            ),
        ]
        response = client.models.generate_content(
                    model="gemini-3.5-flash",
                    contents=contents_payload,
                    config=types.GenerateContentConfig(
                        temperature=0
                    ),
                )

        # response = client.models.generate_content(
        #     model="gemini-2.5-flash",
        #     contents=[
        #         SYSTEM_PROMPT,
        #         user_prompt,
        #         audio_file,
        #     ],  # Pass the file object directly
        # )
        print(response.text)
        text = response.text

        text = response.text

        return parse_gemini_json(text)
    else:

        user_prompt = f"""
CURRENT SERVICE:
{service}

CURRENT STEP:
{current_step}

STEP INFORMATION:
{json.dumps(step_info, indent=2)}

CURRENT USER DATA:
{json.dumps(user_data, indent=2)}

MASTER USER DATA:
{json.dumps(user_master_data, indent=2)}

USER MESSAGE:
{user_message}

IMPORTANT:
- Skip already available fields
- Continue workflow naturally
- Answer side questions briefly
- Return ONLY valid JSON
"""

        response = model.generate_content(
            [SYSTEM_PROMPT, user_prompt], generation_config={"temperature": 0}
        )
        print(response.text)
        text = response.text

        return parse_gemini_json(text)
    

out_format = {
    "transcripted_text":"the text or transcription of the user's audio",
    "out":True,
    "language":"en for english and hi for hindi and pb for punjabi"
}

in_format = {
    "transcripted_text":"the text or transcription of the user's audio",
    "out":False,
    "language":"en for english and hi for hindi and pb for punjabi"
}
    
def handle_welcome_bls_international(chat_is,audio:bool):
    print(chat_is,audio)
    if True:
        if audio:
            prompt=f'''
This is a whatsapp portal for bls international.\
You will be given message from user which can be in hindi or english. You have to distinguish whether he or she is greeting or mentioning about their interest or saying something about some projects or daily progress report or any isue.\
If the user is greeting then return in {in_format} this format\
else in any other case return in {out_format} this format.\
Only return the json in format nothing else and don't add any extra text to it.\
In both the cases return the language of user in the language key.\
'''
            file_obj = chat_is['audio']
            file_id = file_obj['id']
            print("Audio ID Received:", file_id,datetime.now())
            url = "https://backend.aisensy.com/direct-apis/t1/get-media"

            payload = { "id": file_id }
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhc3Npc3RhbnRJZCI6IjZhMDQyM2E5ZDI4YTRjMzNkMTIxOWQ2ZSIsImNsaWVudElkIjoiNjg5YjczNmEwYWJmZTYyNmRkMDQwMmQwIiwiaWF0IjoxNzc4NjU3Njk3fQ.K03wN3Tg_qBPh8YGJ8AxNwhjaWMkP7FCf8DZyUmIiv8"
            }
            response = requests.post(url, json=payload, headers=headers)
            # file_name=f"{sender}_{datetime.now()}.mp3"
            response= response.json()
            print("Audio Bytes Received (From Meta)",file_id,datetime.now())
            buffer_data = bytes(response['data'])
            file_name=f"received_audio_{datetime.now()}.mp3"
            final_file_location=AUDIO_RECEIVED_LOCATION +file_name
            with open(final_file_location,'wb') as f:
                f.write(buffer_data)
            print("Audio Saved:",file_id,datetime.now())
            client = genai_new.Client(api_key=GEMINI_API_KEY)
            audio_file = client.files.upload(file=final_file_location)
            response = client.models.generate_content(
                        model='gemini-3.5-flash',
                        contents=[prompt, audio_file] # Pass the file object directly
                        )
            print(response)
            cleaned = re.sub(r"```json|```", "", response.text).strip()
            cleaned = cleaned.replace(" '",' "')
            cleaned = cleaned.replace("' ",'" ')
            cleaned = cleaned.replace("':",'":')
            cleaned = cleaned.replace(":'",':"')
            cleaned = cleaned.replace("'}",'"}')
            cleaned = cleaned.replace("{'",'{"')
            cleaned = cleaned.replace(",'",',"')
            cleaned = cleaned.replace("',",'",')
            cleaned = cleaned.replace("True",'true')
            cleaned = cleaned.replace("False",'false')
            print('cleaned',cleaned)
            services_by_gpt= json.loads(cleaned)

            # services_by_gpt = format_response(response.text)
            print("services by audio gpt", services_by_gpt)
            
        else:
            user_text =chat_is['text']['body']

            prompt=f'''
This is a whatsapp portal for bls international.\
You will be given message from user which can be in hindi or english. You have to distinguish whether he or she is greeting or mentioning about their interest or saying something about some projects or daily progress report or any isue.\
If the user is greeting then return in {in_format} this format\
else in any other case return in {out_format} this format.\
Only return the json in format nothing else.\
And kindly return json only that i can convert into dictionary without any error.\
In both the cases return the language of user in the language key.\
User Text:{user_text}
'''
            model = genai.GenerativeModel('models/gemini-3.5-flash')
            response = model.generate_content([prompt])
            print(response)
            cleaned = re.sub(r"```json|```", "", response.text).strip()
            cleaned = cleaned.replace(" '",' "')
            cleaned = cleaned.replace("' ",'" ')
            cleaned = cleaned.replace("':",'":')
            cleaned = cleaned.replace(":'",':"')
            cleaned = cleaned.replace("'}",'"}')
            cleaned = cleaned.replace("{'",'{"')
            cleaned = cleaned.replace(",'",',"')
            cleaned = cleaned.replace("',",'",')
            cleaned = cleaned.replace("True",'true')
            cleaned = cleaned.replace("False",'false')
            print('cleaned',cleaned)
            services_by_gpt= json.loads(cleaned)
            print("services by audio gpt", services_by_gpt)
    return services_by_gpt
