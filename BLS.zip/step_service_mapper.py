service_step_decription = {
    "registration": {
        "account_setup": {
            "decription": "In this step we ask user about their basic details such as full name,passport number,date of birth,email address",
            "valid_answer": "The valid answer for this step will be all the details that are asked to user",
            "next_step": {
                "step": "choose_service",
                "question": "The question should contain the services that are currently available with us. The question should be good look wise.",
                "description": "In this step we ask user to choose a service from our service list i.e appointment booking,flight booking,additional services"
            }
        }
    },
    "main": {
        "choose_service": {
            "desription": "In this step we ask user to choose a service from our service list i.e appointment booking,flight booking,additional services",
            "valid_answer": "The valid answer should be one service from our service list i.e appointment booking,flight booking,additional services",
            "next_step": [
                {
                    "step": "additional_service_menu",
                    "question": "The question should contain the additional services that are available with us",
                    "description": "In this step we will ask the user the additional services that are available with us"
                }
            ]
        }
    },
    "additional_service": {

        "additional_service_menu": {
            "description": "In this step we have asked the user the additional services that are available with us",
            "valid_answer": "Courier,Photo copy - Black and White,SMS,Call back service(STS),Premium Lounge,Printing,Form Filling,Flexi hours – Passport collection,Door Step Services,Prime Time Appointment,Photo booth,Sim Card Service,Logistic Charges (For Nepal & Colombo),Courier Assurance,Doctor on call,BLS Service Charges",
            "next_step": [

                {
                    "step": "courier_start",
                    "question": "Ask user for full name to start Courier Service request",
                    "description": "Courier service workflow start"
                },

                {
                    "step": "photo_copy_black_and_white_start",
                    "question": "Ask user for full name to start Photo copy service",
                    "description": "Photo copy service workflow start"
                },

                {
                    "step": "sms_start",
                    "question": "Ask user for full name to activate SMS Service",
                    "description": "SMS service workflow start"
                },

                {
                    "step": "call_back_service_start",
                    "question": "Ask user for full name to schedule callback service",
                    "description": "Call back service workflow start"
                },

                {
                    "step": "premium_lounge_start",
                    "question": "Ask user for full name to start Premium Lounge service",
                    "description": "Premium Lounge workflow start"
                },

                {
                    "step": "printing_start",
                    "question": "Ask user for full name to start Printing service",
                    "description": "Printing service workflow start"
                },

                {
                    "step": "form_filling_start",
                    "question": "Ask user for full name to start Form Filling assistance",
                    "description": "Form filling workflow start"
                },

                {
                    "step": "flexi_hours_passport_collection_start",
                    "question": "Ask user for full name to start Flexi Hours Passport Collection",
                    "description": "Flexi Hours Passport Collection workflow start"
                },

                {
                    "step": "door_step_services_start",
                    "question": "Ask user for full name to start Door Step Service",
                    "description": "Door Step Services workflow start"
                },

                {
                    "step": "prime_time_appointment_start",
                    "question": "Ask user for full name to start Prime Time Appointment",
                    "description": "Prime Time Appointment workflow start"
                },

                {
                    "step": "photo_booth_start",
                    "question": "Ask user for full name to start Photo Booth service",
                    "description": "Photo Booth workflow start"
                },

                {
                    "step": "sim_card_service_start",
                    "question": "Ask user for full name to start SIM Card Service",
                    "description": "SIM Card Service workflow start"
                },

                {
                    "step": "logistic_charges_start",
                    "question": "Ask user for full name to start Logistic Charges service",
                    "description": "Logistic Charges workflow start"
                },

                {
                    "step": "courier_assurance_start",
                    "question": "Ask user for full name to start Courier Assurance service",
                    "description": "Courier Assurance workflow start"
                },

                {
                    "step": "doctor_on_call_start",
                    "question": "Ask user for full name to start Doctor On Call service",
                    "description": "Doctor On Call workflow start"
                },

                {
                    "step": "bls_service_charges_start",
                    "question": "Ask user for full name to know BLS Service Charges",
                    "description": "BLS Service Charges workflow start"
                }

            ]
        },

        # =========================================================
        # COURIER
        # =========================================================

        "courier_start": {
            "description": "In this step we ask user full name for courier service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "courier_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number"
            }
        },

        "courier_passport_number": {
            "description": "Ask passport number for courier service",
            "valid_answer": "Valid passport number",
            "next_step": {
                "step": "courier_delivery_address",
                "question": "Please share your delivery address.",
                "description": "Ask delivery address"
            }
        },

        "courier_delivery_address": {
            "description": "Ask delivery address",
            "valid_answer": "Valid delivery address",
            "next_step": {
                "step": "courier_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number"
            }
        },

        "courier_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "courier_completed",
                "question": "Your Courier Service request has been submitted successfully.",
                "description": "Courier service completed"
            }
        },

        # =========================================================
        # PREMIUM LOUNGE
        # =========================================================

        "premium_lounge_start": {
            "description": "Ask full name for Premium Lounge service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "premium_lounge_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number"
            }
        },

        "premium_lounge_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Valid passport number",
            "next_step": {
                "step": "premium_lounge_appointment_date",
                "question": "Please share your appointment date.",
                "description": "Ask appointment date"
            }
        },

        "premium_lounge_appointment_date": {
            "description": "Ask appointment date",
            "valid_answer": "Valid appointment date",
            "next_step": {
                "step": "premium_lounge_center_name",
                "question": "Please share your visa application centre name.",
                "description": "Ask visa centre"
            }
        },

        "premium_lounge_center_name": {
            "description": "Ask centre name",
            "valid_answer": "Valid centre name",
            "next_step": {
                "step": "premium_lounge_completed",
                "question": "Your Premium Lounge request has been submitted successfully.",
                "description": "Premium Lounge completed"
            }
        },

        # =========================================================
        # SMS SERVICE
        # =========================================================

        "sms_start": {
            "description": "Ask full name for SMS service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "sms_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number"
            }
        },

        "sms_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Valid passport number",
            "next_step": {
                "step": "sms_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number"
            }
        },

        "sms_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "sms_completed",
                "question": "SMS Service has been activated successfully.",
                "description": "SMS service completed"
            }
        },

        # =========================================================
        # FORM FILLING
        # =========================================================

        "form_filling_start": {
            "description": "Ask full name for form filling service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "form_filling_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number"
            }
        },

        "form_filling_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Valid passport number",
            "next_step": {
                "step": "form_filling_visa_type",
                "question": "Which visa category are you applying for?",
                "description": "Ask visa type"
            }
        },

        "form_filling_visa_type": {
            "description": "Ask visa type",
            "valid_answer": "Valid visa type",
            "next_step": {
                "step": "form_filling_mobile_number",
                "question": "Please share your mobile number.",
                "description": "Ask mobile number"
            }
        },

        "form_filling_mobile_number": {
            "description": "Ask mobile number",
            "valid_answer": "Valid mobile number",
            "next_step": {
                "step": "form_filling_completed",
                "question": "Your Form Filling Assistance request has been submitted successfully.",
                "description": "Form filling completed"
            }
        },

        # =========================================================
        # PRIME TIME APPOINTMENT
        # =========================================================

        "prime_time_appointment_start": {
            "description": "Ask full name for Prime Time Appointment",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "prime_time_appointment_passport_number",
                "question": "Please share your passport number.",
                "description": "Ask passport number"
            }
        },

        "prime_time_appointment_passport_number": {
            "description": "Ask passport number",
            "valid_answer": "Valid passport number",
            "next_step": {
                "step": "prime_time_appointment_preferred_date",
                "question": "Please share your preferred appointment date.",
                "description": "Ask preferred date"
            }
        },

        "prime_time_appointment_preferred_date": {
            "description": "Ask preferred date",
            "valid_answer": "Valid preferred date",
            "next_step": {
                "step": "prime_time_appointment_completed",
                "question": "Your Prime Time Appointment request has been submitted successfully.",
                "description": "Prime Time Appointment completed"
            }
        },

        # =========================================================
        # PHOTO BOOTH
        # =========================================================

        "photo_booth_start": {
            "description": "Ask full name for Photo Booth service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "photo_booth_number_of_photos",
                "question": "How many photographs do you need?",
                "description": "Ask number of photographs"
            }
        },

        "photo_booth_number_of_photos": {
            "description": "Ask number of photos",
            "valid_answer": "Valid number of photographs",
            "next_step": {
                "step": "photo_booth_completed",
                "question": "Your Photo Booth request has been submitted successfully.",
                "description": "Photo Booth completed"
            }
        },

        # =========================================================
        # SIM CARD SERVICE
        # =========================================================

        "sim_card_service_start": {
            "description": "Ask full name for SIM Card service",
            "valid_answer": "Full name of the user",
            "next_step": {
                "step": "sim_card_service_destination_country",
                "question": "Which country are you travelling to?",
                "description": "Ask destination country"
            }
        },

        "sim_card_service_destination_country": {
            "description": "Ask destination country",
            "valid_answer": "Valid destination country",
            "next_step": {
                "step": "sim_card_service_travel_date",
                "question": "Please share your travel date.",
                "description": "Ask travel date"
            }
        },

        "sim_card_service_travel_date": {
            "description": "Ask travel date",
            "valid_answer": "Valid travel date",
            "next_step": {
                "step": "sim_card_service_completed",
                "question": "Your SIM Card Service request has been submitted successfully.",
                "description": "SIM Card Service completed"
            }
        }

    }

}